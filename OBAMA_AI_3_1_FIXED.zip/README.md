# OBAMA — Mubarek Voice Assistant

OBAMA is an Android Java voice/chat assistant with English + Amharic speech, streaming Gemini chat, file attachments, local conversation history, named AI voice personalities, hands-free mode, themes and a ChatGPT-style composer.

## Setup

1. Open the project in Android Studio.
2. Add your Gemini API key to the Gradle user properties file (`~/.gradle/gradle.properties`):

   `GEMINI_API_KEY=YOUR_KEY`

3. Sync Gradle and run the app.
4. Never commit a real API key to GitHub.

## AI and voice

The chat layer uses Gemini `streamGenerateContent` with model fallback. Natural voice uses Gemini TTS with named voices such as Sulafat, Charon, Achird, Fenrir, Aoede and Orus. The app also has Android Text-to-Speech as a local fallback.

## Features

- OBAMA branding
- Mubarek assistant persona
- English / አማርኛ
- ChatGPT-style message composer
- File attachment button (single file, up to 7 MB)
- Streaming responses
- Copy / speak / regenerate response actions
- Named voice personalities
- Natural cloud voice option
- Hands-free voice mode
- Voice greeting
- Chat history
- Light / Midnight / Ocean / Sunset themes
- Local guest/account flow

## Security note

For production distribution, move Gemini API calls behind your own backend or use an appropriate short-lived/ephemeral authentication design. A key embedded in a client APK can be extracted.


## GitHub Actions
The repository includes `.github/workflows/build.yml`. It uses JDK 17 and Gradle 8.7 and builds `app-debug.apk`. The Node.js 20 and Ubuntu migration notices shown by GitHub are warnings, not Android build errors.

## Gemini API key
The debug build can be produced without a key. To use Gemini at runtime during local development, add `GEMINI_API_KEY=...` to your Gradle user properties. Do not commit a real API key to GitHub. For a public release, move Gemini calls to a secure backend.


## Version 3.1 notes
- GitHub builds: add a repository secret named `GEMINI_API_KEY` (the older name `GEMINI_KEY` also works). The workflow passes it to Gradle at build time, so the key is never saved in the repository.
- Replies stream in and are spoken sentence by sentence, so the voice starts quickly.
- The animated offline screen, chat sound effects and the About / 3D contact page are available again (About: info icon on the chat screen, or Settings).
- Natural AI voices use the Gemini `/interactions` text-to-speech endpoint; voice files are cached on the phone (up to 40).
