package com.mubarek.ai;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Online voice (Gemini text-to-speech).
 * Sentences are fetched in order while earlier ones are already playing,
 * so speech starts quickly. All session calls must be made on the main thread.
 */
final class CloudTts {
    interface Listener {
        void onStart();
        void onDone(boolean ok, String error);
    }

    private static final String[] MODELS = {"gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts"};
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static volatile int generation;
    private static MediaPlayer player;
    private static final ArrayDeque<File> ready = new ArrayDeque<>();
    private static Context appCtx;
    private static String sKey, sVoice, sStyle;
    private static Listener sListener;
    private static int sPending;
    private static boolean sEnded, sPlaying, sStarted, sFailed;

    /** Plays one piece of text. */
    static void speak(Context ctx, String text, String key, String voice, String style, Listener l) {
        begin(ctx, key, voice, style, l);
        enqueue(text);
        end();
    }

    /** Starts a speaking session. Then call enqueue() for each sentence and end() when finished. */
    static void begin(Context ctx, String key, String voice, String style, Listener l) {
        stop();
        appCtx = ctx.getApplicationContext();
        sKey = key; sVoice = voice; sStyle = style; sListener = l;
        ready.clear();
        sPending = 0; sEnded = false; sPlaying = false; sStarted = false; sFailed = false;
    }

    static void enqueue(final String text) {
        if (sFailed || appCtx == null || text == null || text.trim().isEmpty()) return;
        if (sKey == null || sKey.trim().isEmpty()) { fail("Gemini API key is missing."); return; }
        final int g = generation;
        final Context ctx = appCtx;
        final String key = sKey, voice = sVoice, style = sStyle;
        sPending++;
        IO.execute(() -> {
            File f = null;
            String err = null;
            try {
                f = new File(ctx.getCacheDir(), "obama_voice_" + hash(text + voice + style) + ".wav");
                if (!f.exists() || f.length() == 0) {
                    if (g != generation) return;
                    generate(f, text, key, voice, style);
                    trimCache(ctx);
                }
            } catch (Exception e) {
                err = e.getMessage() == null ? "Voice error" : e.getMessage();
                f = null;
            }
            final File ff = f;
            final String ee = err;
            MAIN.post(() -> {
                if (g != generation) return;
                sPending--;
                if (ee != null) { fail(ee); return; }
                ready.add(ff);
                pump();
            });
        });
    }

    static void end() {
        sEnded = true;
        pump();
    }

    static void stop() {
        generation++;
        ready.clear();
        sListener = null;
        sPlaying = false;
        sPending = 0;
        sEnded = false;
        MediaPlayer p = player;
        player = null;
        if (p != null) {
            try { p.stop(); } catch (Exception ignored) { }
            try { p.release(); } catch (Exception ignored) { }
        }
    }

    // ---- playback ----
    private static void pump() {
        if (sFailed || sPlaying) return;
        File f = ready.poll();
        if (f != null) { play(f); return; }
        if (sEnded && sPending <= 0) {
            Listener l = sListener;
            sListener = null;
            if (l != null) l.onDone(true, null);
        }
    }

    private static void fail(String err) {
        sFailed = true;
        ready.clear();
        Listener l = sListener;
        sListener = null;
        if (l != null) l.onDone(false, err);
    }

    private static void play(File f) {
        sPlaying = true;
        final int g = generation;
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(m -> {
                if (g != generation) return;
                if (!sStarted) {
                    sStarted = true;
                    if (sListener != null) sListener.onStart();
                }
                m.start();
            });
            mp.setOnCompletionListener(m -> {
                try { m.release(); } catch (Exception ignored) { }
                if (player == m) player = null;
                if (g != generation) return;
                sPlaying = false;
                pump();
            });
            mp.setOnErrorListener((m, what, extra) -> {
                try { m.release(); } catch (Exception ignored) { }
                if (player == m) player = null;
                if (g == generation) { sPlaying = false; fail("Audio playback failed."); }
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            sPlaying = false;
            fail(e.getMessage() == null ? "Audio error" : e.getMessage());
        }
    }

    // ---- network ----
    private static void generate(File out, String text, String key, String voice, String style) throws Exception {
        Exception last = null;
        for (String model : MODELS) {
            try {
                byte[] audio = fetch(model, text, key, voice, style);
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    boolean riff = audio.length >= 12 && audio[0] == 'R' && audio[1] == 'I' && audio[2] == 'F' && audio[3] == 'F';
                    if (!riff) writeWavHeader(fos, audio.length, 24000, 1, 16);
                    fos.write(audio);
                }
                return;
            } catch (Exception e) { last = e; }
        }
        throw last != null ? last : new Exception("No audio");
    }

    private static byte[] fetch(String model, String text, String key, String voice, String style) throws Exception {
        JSONObject ann = new JSONObject().put("type", "speech_metadata").put("style", style);
        JSONObject content = new JSONObject().put("type", "text").put("text", text)
                .put("annotations", new JSONArray().put(ann));
        JSONObject input = new JSONObject().put("type", "user_input").put("content", new JSONArray().put(content));
        JSONObject body = new JSONObject()
                .put("model", model)
                .put("input", new JSONArray().put(input))
                .put("response_format", new JSONObject().put("type", "audio"))
                .put("generation_config", new JSONObject().put("speech_config",
                        new JSONArray().put(new JSONObject().put("voice", voice))));

        HttpURLConnection c = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(90000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        if (code != 200) {
            String msg = "";
            try { msg = new JSONObject(sb.toString()).getJSONObject("error").getString("message"); } catch (Exception ignored) { }
            throw new Exception("Voice error " + code + (msg.isEmpty() ? "" : ": " + msg));
        }
        String data = findAudio(new JSONObject(sb.toString()));
        if (data == null) throw new Exception("The voice server returned no audio");
        return Base64.decode(data, Base64.DEFAULT);
    }

    /** Finds the last {"type":"audio","data":"..."} anywhere in the response. */
    private static String findAudio(Object node) {
        String found = null;
        try {
            if (node instanceof JSONObject) {
                JSONObject o = (JSONObject) node;
                if ("audio".equals(o.optString("type")) && o.optString("data", "").length() > 0) found = o.getString("data");
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String r = findAudio(o.get(it.next()));
                    if (r != null) found = r;
                }
            } else if (node instanceof JSONArray) {
                JSONArray a = (JSONArray) node;
                for (int i = 0; i < a.length(); i++) {
                    String r = findAudio(a.get(i));
                    if (r != null) found = r;
                }
            }
        } catch (Exception ignored) { }
        return found;
    }

    // ---- helpers ----
    private static void writeWavHeader(OutputStream os, int dataLength, int sampleRate, int channels, int bits) throws Exception {
        int byteRate = sampleRate * channels * bits / 8;
        int block = channels * bits / 8;
        os.write(new byte[]{'R', 'I', 'F', 'F'}); le(os, 36 + dataLength, 4);
        os.write(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        le(os, 16, 4); le(os, 1, 2); le(os, channels, 2); le(os, sampleRate, 4); le(os, byteRate, 4); le(os, block, 2); le(os, bits, 2);
        os.write(new byte[]{'d', 'a', 't', 'a'}); le(os, dataLength, 4);
    }

    private static void le(OutputStream os, int v, int n) throws Exception {
        for (int i = 0; i < n; i++) os.write((v >> (8 * i)) & 255);
    }

    private static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte x : d) b.append(String.format("%02x", x));
            return b.substring(0, 24);
        } catch (Exception e) { return String.valueOf(s.hashCode()); }
    }

    /** Keeps the saved voice files from growing forever: at most 40 are kept. */
    private static void trimCache(Context ctx) {
        try {
            File[] files = ctx.getCacheDir().listFiles((dir, name) -> name.startsWith("obama_voice_"));
            if (files == null || files.length <= 40) return;
            Arrays.sort(files, Comparator.comparingLong(File::lastModified));
            for (int i = 0; i < files.length - 40; i++) files[i].delete();
        } catch (Exception ignored) { }
    }
}
