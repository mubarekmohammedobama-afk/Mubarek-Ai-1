# OBAMA — Mubarek Voice Assistant

OBAMA is an Android Java voice/chat assistant with English + Amharic speech, streaming Gemini chat, file attachments, local conversation history, named AI voice personalities, hands-free mode, themes and a ChatGPT-style composer.

## Setup

1. Open the project in Android Studio.
2. Add your Gemini API key to the Gradle user properties file (`~/.gradle/gradle.properties`):

   `GEMINI_API_KEY=YOUR_KEY`

3. Sync Gradle and run the app.
4. Never commit a real API key to GitHub.

## AI and voice

The chat layer uses Gemini `streamGenerateContent` with model fallback. Natural voice uses Gemini TTS with named voices such as Sulafat, Charon, Achird, Fenrir, Aoede and Orus. The app also has Android Text-to-Speech as a local fallback.

## Features

- OBAMA branding
- Mubarek assistant persona
- English / አማርኛ
- ChatGPT-style message composer
- File attachment button (single file, up to 7 MB)
- Streaming responses
- Copy / speak / regenerate response actions
- Named voice personalities
- Natural cloud voice option
- Hands-free voice mode
- Voice greeting
- Chat history
- Light / Midnight / Ocean / Sunset themes
- Local guest/account flow

## Security note

For production distribution, move Gemini API calls behind your own backend or use an appropriate short-lived/ephemeral authentication design. A key embedded in a client APK can be extracted.
