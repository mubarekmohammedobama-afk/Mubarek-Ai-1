package com.mubarek.ai;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;

public class HistoryActivity extends AppCompatActivity {
    private Pal pal;
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pal = Pal.get(this);
        UI.window(this, pal);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(pal.bg);
        root.setFitsSystemWindows(true);
        root.addView(UI.topBar(this, "History", pal));

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(this, 16), UI.dp(this, 4), UI.dp(this, 16), UI.dp(this, 24));
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));
        setContentView(root);
        refresh();
    }

    private void refresh() {
        list.removeAllViews();
        JSONArray all = ChatStore.all(this);
        if (all.length() == 0) {
            TextView t = UI.tv(this, "No chats yet.\nYour conversations will appear here.", 16, pal.sub, false);
            t.setGravity(Gravity.CENTER);
            list.addView(t, UI.lp(this, UI.MATCH, UI.WRAP, 0, 80, 0, 0));
            return;
        }
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (int i = 0; i < all.length(); i++) {
            try {
                JSONObject c = all.getJSONObject(i);
                final String id = c.getString("id");
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setBackground(UI.rect(this, pal.card, 16));
                row.setPadding(UI.dp(this, 16), UI.dp(this, 14), UI.dp(this, 8), UI.dp(this, 14));
                row.setClickable(true);

                LinearLayout txt = new LinearLayout(this);
                txt.setOrientation(LinearLayout.VERTICAL);
                TextView title = UI.tv(this, c.getString("title"), 16, pal.text, true);
                title.setMaxLines(1);
                title.setEllipsize(TextUtils.TruncateAt.END);
                txt.addView(title);
                int n = c.getJSONArray("msgs").length();
                txt.addView(UI.tv(this, df.format(new Date(c.getLong("time"))) + "  ·  " + n + " messages", 12, pal.sub, false));
                row.addView(txt, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));

                TextView del = UI.tv(this, "✕", 18, pal.sub, true);
                del.setGravity(Gravity.CENTER);
                del.setClickable(true);
                del.setOnClickListener(v -> { ChatStore.delete(this, id); refresh(); });
                row.addView(del, new LinearLayout.LayoutParams(UI.dp(this, 48), UI.dp(this, 48)));

                row.setOnClickListener(v -> {
                    Intent it = new Intent(this, MainActivity.class);
                    it.putExtra("conv", id);
                    it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(it);
                    finish();
                });
                list.addView(row, UI.lp(this, UI.MATCH, UI.WRAP, 0, 6, 0, 6));
            } catch (Exception ignored) { }
        }
    }
}
