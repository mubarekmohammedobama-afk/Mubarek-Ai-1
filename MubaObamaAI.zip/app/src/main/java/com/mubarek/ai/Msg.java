package com.mubarek.ai;

final class Msg {
    final boolean user;
    String text;
    boolean skip; // failed messages are shown but not sent back to the AI
    Msg(boolean user, String text) { this.user = user; this.text = text; }
}
