package com.mubarek.ai;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private Pal pal;
    private int themeAtCreate;
    private GlowOrbView orb;
    private MicButton mic;
    private TextView status, langChip;
    private EditText input;
    private RecyclerView rv;
    private Adapter adapter;
    private OfflineView offline;

    private final List<Msg> msgs = new ArrayList<>();
    private String convId;

    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false, amharic = false, voiceOk = true, greeting = false;

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private Boolean lastOnline = null;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private int dp(float v) { return UI.dp(this, v); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pal = Pal.get(this);
        themeAtCreate = Prefs.theme(this);
        amharic = Prefs.amharic(this);
        UI.window(this, pal);

        convId = getIntent().getStringExtra("conv");
        if (convId != null) loadConversation(); else convId = String.valueOf(System.currentTimeMillis());
        if (msgs.isEmpty()) addWelcome();

        buildUi();
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { main.post(() -> orb.setState(GlowOrbView.State.SPEAKING)); }
                    @Override public void onDone(String id) { main.post(() -> finishSpeaking(id)); }
                    @Override public void onError(String id) { main.post(() -> finishSpeaking(id)); }
                });
                ttsReady = true;
                applyTts();
            }
        });
    }

    // ---------- UI ----------
    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(pal.bg);
        root.setFitsSystemWindows(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), 0, dp(6), 0);
        top.addView(UI.tv(this, "Muba-Obama AI", 20, pal.text, true), new LinearLayout.LayoutParams(0, UI.WRAP, 1f));

        langChip = UI.tv(this, amharic ? "አማ" : "EN", 14, pal.text, true);
        langChip.setBackground(UI.rect(this, pal.card, 12));
        langChip.setPadding(dp(12), dp(7), dp(12), dp(7));
        langChip.setClickable(true);
        langChip.setOnClickListener(v -> {
            amharic = !amharic;
            Prefs.setAmharic(this, amharic);
            applyTts();
            langChip.setText(amharic ? "አማ" : "EN");
        });
        top.addView(langChip, UI.lp(this, UI.WRAP, UI.WRAP, 0, 0, 4, 0));
        top.addView(icon(android.R.drawable.ic_menu_add, v -> newChat()));
        top.addView(icon(android.R.drawable.ic_menu_recent_history, v -> startActivity(new Intent(this, HistoryActivity.class))));
        top.addView(icon(android.R.drawable.ic_menu_preferences, v -> startActivity(new Intent(this, SettingsActivity.class))));
        top.addView(icon(android.R.drawable.ic_menu_info_details, v -> startActivity(new Intent(this, AboutActivity.class))));
        col.addView(top, new LinearLayout.LayoutParams(UI.MATCH, dp(56)));

        orb = new GlowOrbView(this, null);
        orb.setAccent(pal.accent);
        col.addView(orb, new LinearLayout.LayoutParams(UI.MATCH, dp(210)));

        status = UI.tv(this, "Tap the mic and talk", 14, pal.sub, false);
        status.setGravity(Gravity.CENTER);
        col.addView(status, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        rv = new RecyclerView(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter();
        rv.setAdapter(adapter);
        rv.setClipToPadding(false);
        rv.setPadding(0, dp(8), 0, dp(8));
        col.addView(rv, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(6), dp(8), dp(8));

        input = new EditText(this);
        input.setHint("Message Muba-Obama AI");
        input.setHintTextColor(pal.sub);
        input.setTextColor(pal.text);
        input.setMaxLines(3);
        input.setBackground(UI.rect(this, pal.card, 26));
        input.setPadding(dp(18), dp(12), dp(18), dp(12));
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendTyped(); return true; }
            return false;
        });
        bar.addView(input, new LinearLayout.LayoutParams(0, UI.WRAP, 1f));

        ImageButton send = new ImageButton(this);
        GradientDrawable sg = new GradientDrawable();
        sg.setShape(GradientDrawable.OVAL);
        sg.setColor(pal.accent);
        send.setBackground(sg);
        send.setImageResource(android.R.drawable.ic_menu_send);
        send.setColorFilter(0xFFFFFFFF);
        send.setOnClickListener(v -> sendTyped());
        bar.addView(send, UI.lp(this, dp(46), dp(46), 8, 0, 0, 0));

        mic = new MicButton(this);
        mic.setAccent(pal.accent);
        mic.setOnClickListener(v -> micPressed());
        bar.addView(mic, new LinearLayout.LayoutParams(dp(70), dp(70)));
        col.addView(bar, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        offline = new OfflineView(this);
        offline.setVisibility(View.GONE);
        offline.setClickable(true);
        FrameLayout.LayoutParams ol = new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH);
        ol.topMargin = dp(56);
        root.addView(offline, ol);

        setContentView(root);
    }

    private ImageButton icon(int res, View.OnClickListener l) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(pal.text);
        b.setBackground(null);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    // ---------- chat list ----------
    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final TextView t;
            VH(FrameLayout f, TextView t) { super(f); this.t = t; }
        }

        @Override public VH onCreateViewHolder(ViewGroup parent, int type) {
            FrameLayout f = new FrameLayout(parent.getContext());
            f.setLayoutParams(new RecyclerView.LayoutParams(UI.MATCH, UI.WRAP));
            TextView t = new TextView(parent.getContext());
            t.setTextSize(16);
            t.setPadding(dp(14), dp(10), dp(14), dp(10));
            t.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.8f));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(UI.WRAP, UI.WRAP);
            lp.setMargins(dp(10), dp(4), dp(10), dp(4));
            f.addView(t, lp);
            return new VH(f, t);
        }

        @Override public void onBindViewHolder(VH h, int pos) {
            Msg m = msgs.get(pos);
            h.t.setText(m.text);
            h.t.setBackground(UI.rect(MainActivity.this, m.user ? pal.accent : pal.card, 18));
            h.t.setTextColor(m.user ? 0xFFFFFFFF : pal.text);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) h.t.getLayoutParams();
            lp.gravity = m.user ? Gravity.END : Gravity.START;
            h.t.setLayoutParams(lp);
        }

        @Override public int getItemCount() { return msgs.size(); }
    }

    private void scrollEnd() { if (!msgs.isEmpty()) rv.scrollToPosition(msgs.size() - 1); }

    private void loadConversation() {
        JSONObject c = ChatStore.get(this, convId);
        if (c == null) return;
        try {
            JSONArray a = c.getJSONArray("msgs");
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                msgs.add(new Msg(o.getBoolean("u"), o.getString("t")));
            }
        } catch (Exception ignored) { }
    }

    private void newChat() {
        if (tts != null) tts.stop();
        CloudTts.stop();
        msgs.clear();
        convId = String.valueOf(System.currentTimeMillis());
        addWelcome();
        adapter.notifyDataSetChanged();
        orb.setState(GlowOrbView.State.IDLE);
        status.setText("New chat. Tap the mic and talk");
    }

    // ---------- voice ----------
    private void applyTts() {
        if (!ttsReady) return;
        tts.setSpeechRate(Prefs.rate(this));
        tts.setPitch(Prefs.pitch(this));
        voiceOk = true;
        Locale loc = amharic ? new Locale("am", "ET") : Locale.getDefault();
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            voiceOk = false;
            if (amharic) status.setText("አማርኛ ተመርጧል. Using the online Amharic voice");
            return;
        }
        String vn = Prefs.voice(this);
        if (!vn.isEmpty()) {
            try {
                for (Voice v : tts.getVoices()) {
                    if (v.getName().equals(vn) && v.getLocale().getLanguage().equals(loc.getLanguage())) {
                        tts.setVoice(v);
                        break;
                    }
                }
            } catch (Exception ignored) { }
        }
        if (amharic) status.setText("አማርኛ ተመርጧል. Tap the mic and talk");
    }

    // ---------- welcome + greeting ----------
    private static final String[] GREET_EN = {
            "I'm listening. How can I help you?",
            "Hi! Go ahead, I'm all ears.",
            "Welcome! Tell me what you need.",
            "Sure, I'm here to help. What's on your mind?"};
    private static final String[] GREET_AM = {
            "እሰማለሁ። ምን ልርዳዎት?",
            "ሰላም! ንገሩኝ፣ እሰማለሁ።",
            "እንኳን ደህና መጡ! ምን ላግዝዎት?",
            "ለመርዳት ዝግጁ ነኝ። ምን ልርዳዎት?"};

    private void addWelcome() {
        String n = Prefs.displayName(this);
        boolean named = !n.equals("Guest") && !n.isEmpty();
        String t = amharic
                ? "ሰላም" + (named ? " " + n : "") + "! እኔ ሙባ ኦባማ ኤአይ ነኝ። ጥያቄ ይጠይቁኝ፣ ሃሳብ ይጠይቁኝ ወይም ዝም ብለን እንወያይ። ማይክን ይንኩና ይናገሩ፣ ወይም ከታች ይጻፉ።"
                : "Hi" + (named ? " " + n : " there") + "! I'm Muba-Obama AI.\n\nI can answer questions, help with ideas, translate, and chat in English or አማርኛ. Tap the mic and talk, or type below.";
        Msg w = new Msg(false, t);
        w.skip = true; // shown on screen only, never sent to the AI or saved
        msgs.add(w);
    }

    private String firstUserText() {
        for (Msg m : msgs) if (m.user && !m.skip) return m.text;
        return "Chat";
    }

    private void finishSpeaking(String id) {
        orb.setState(GlowOrbView.State.IDLE);
        if ("greet".equals(id)) {
            if (greeting) { greeting = false; startListening(); }
        } else {
            status.setText("Tap the mic and talk");
        }
    }

    /** Mic tap: say a short friendly line first, then start listening. */
    private void micPressed() {
        if (greeting) { // tapped again: skip the greeting
            greeting = false;
            if (tts != null) tts.stop();
            CloudTts.stop();
            startListening();
            return;
        }
        if (!Prefs.greet(this)
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                || !SpeechRecognizer.isRecognitionAvailable(this)) {
            startListening();
            return;
        }
        String[] set = amharic ? GREET_AM : GREET_EN;
        int idx = (int) (Math.random() * set.length);
        String g = set[idx];
        CloudTts.stop();
        greeting = true;
        status.setText(g);
        if (ttsReady && voiceOk) {
            tts.speak(g, TextToSpeech.QUEUE_FLUSH, null, "greet");
        } else if (amharic || !ttsReady) {
            CloudTts.speak(this, g, getString(R.string.gemini_key), new CloudTts.Listener() {
                @Override public void onStart() { orb.setState(GlowOrbView.State.SPEAKING); }
                @Override public void onDone(boolean ok, String error) {
                    orb.setState(GlowOrbView.State.IDLE);
                    if (greeting) { greeting = false; startListening(); }
                }
            }, "greet_" + (amharic ? "am" : "en") + idx);
        } else {
            greeting = false;
            startListening();
        }
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech recognition is not available on this phone");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        if (tts != null) tts.stop();
        CloudTts.stop();
        SoundFx.play(this, SoundFx.START);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, amharic ? "am-ET" : Locale.getDefault().toLanguageTag());
        recognizer.startListening(i);
        orb.setState(GlowOrbView.State.LISTENING);
        mic.setActive(true);
        status.setText("Listening…");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else status.setText("Microphone permission is needed to talk");
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rms) { orb.setVoiceRms(rms); }
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() { mic.setActive(false); status.setText("Thinking…"); }
        @Override public void onError(int e) {
            mic.setActive(false);
            orb.setState(GlowOrbView.State.IDLE);
            status.setText("Didn't catch that. Tap the mic and try again");
        }
        @Override public void onResults(Bundle r) {
            mic.setActive(false);
            ArrayList<String> list = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) submit(list.get(0));
            else orb.setState(GlowOrbView.State.IDLE);
        }
        @Override public void onPartialResults(Bundle p) {}
        @Override public void onEvent(int t, Bundle p) {}
    };

    // ---------- asking the AI ----------
    private void sendTyped() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        submit(text);
    }

    private String buildBody() throws Exception {
        JSONArray contents = new JSONArray();
        for (int i = Math.max(0, msgs.size() - 21); i < msgs.size(); i++) {
            Msg m = msgs.get(i);
            if (m.skip) continue;
            if (contents.length() == 0 && !m.user) continue;
            contents.put(new JSONObject().put("role", m.user ? "user" : "model")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", m.text))));
        }
        JSONObject sys = new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text",
                "You are Muba-Obama AI, a friendly voice assistant. Keep answers short and easy to say out loud. "
                        + "Always reply in the same language the user speaks or writes, including Amharic (አማርኛ).")));
        return new JSONObject().put("system_instruction", sys).put("contents", contents).toString();
    }

    private void submit(String text) {
        if (!isOnline()) {
            SoundFx.play(this, SoundFx.ERROR);
            status.setText("No internet connection");
            orb.setState(GlowOrbView.State.IDLE);
            return;
        }
        SoundFx.play(this, SoundFx.SEND);
        final Msg userMsg = new Msg(true, text);
        msgs.add(userMsg);
        final String body;
        try { body = buildBody(); }
        catch (Exception e) { status.setText("Error: " + e.getMessage()); return; }
        final Msg placeholder = new Msg(false, "…");
        msgs.add(placeholder);
        adapter.notifyItemRangeInserted(msgs.size() - 2, 2);
        scrollEnd();
        status.setText("Thinking…");
        orb.setState(GlowOrbView.State.IDLE);

        io.execute(() -> {
            String out;
            boolean ok = true;
            try { out = callGemini(body); }
            catch (Exception e) { out = e.getMessage(); ok = false; }
            final String result = out;
            final boolean success = ok;
            main.post(() -> showReply(userMsg, placeholder, result, success));
        });
    }

    private static final String[] MODELS = {"gemini-3.8-flash", "gemini-3.1-flash-lite", "gemini-3-flash-preview"};

    private static class RetryableException extends Exception {
        RetryableException(String m) { super(m); }
    }

    private String callGemini(String body) throws Exception {
        Exception last = null;
        for (int round = 0; round < 2; round++) {
            for (String m : MODELS) {
                try { return callGeminiModel(m, body); }
                catch (RetryableException e) { last = e; }
            }
            try { Thread.sleep(2000); } catch (InterruptedException ignored) { }
        }
        throw new Exception(last == null ? "AI is busy. Try again in a moment." : last.getMessage());
    }

    private String callGeminiModel(String model, String body) throws Exception {
        String key = getString(R.string.gemini_key);
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        if (code != 200) {
            String msg = "";
            try { msg = new JSONObject(sb.toString()).getJSONObject("error").getString("message"); } catch (Exception ignored) { }
            if (code == 503 || code == 429 || code == 404 || code == 500)
                throw new RetryableException("Error " + code + ": " + msg);
            throw new Exception("Error " + code + ": " + msg);
        }
        try {
            return new JSONObject(sb.toString()).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
        } catch (Exception e) {
            throw new Exception("The AI gave no answer. Try asking again.");
        }
    }

    private void showReply(Msg userMsg, Msg placeholder, String text, boolean ok) {
        placeholder.text = text;
        if (!ok) {
            userMsg.skip = true;
            placeholder.skip = true;
            SoundFx.play(this, SoundFx.ERROR);
        }
        adapter.notifyDataSetChanged();
        scrollEnd();
        if (!ok) {
            status.setText("Tap the mic and talk");
            orb.setState(GlowOrbView.State.IDLE);
            return;
        }
        SoundFx.play(this, SoundFx.REPLY);
        String title = firstUserText();
        ChatStore.save(this, convId, title.length() > 40 ? title.substring(0, 40) + "…" : title, msgs);
        status.setText("Speaking…");
        String clean = text.replace("*", "").replace("#", "");
        if (ttsReady && voiceOk) {
            tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "reply");
        } else if (amharic || !ttsReady) {
            if (clean.length() > 1000) clean = clean.substring(0, 1000);
            CloudTts.speak(this, clean, getString(R.string.gemini_key), new CloudTts.Listener() {
                @Override public void onStart() { orb.setState(GlowOrbView.State.SPEAKING); }
                @Override public void onDone(boolean ok, String error) {
                    orb.setState(GlowOrbView.State.IDLE);
                    status.setText(ok ? "Tap the mic and talk" : "Voice error: " + error);
                }
            });
        } else {
            orb.setState(GlowOrbView.State.IDLE);
            status.setText("Tap the mic and talk");
        }
    }

    // ---------- network ----------
    private boolean isOnline() {
        try {
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            return nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Exception e) { return true; }
    }

    private void updateNet() {
        boolean now = isOnline();
        if (lastOnline != null && lastOnline == now) return;
        boolean first = lastOnline == null;
        lastOnline = now;
        if (!now) {
            offline.setVisibility(View.VISIBLE);
            offline.setAlpha(0f);
            offline.animate().alpha(1f).setDuration(350).start();
            if (!first) SoundFx.play(this, SoundFx.ERROR);
        } else {
            offline.animate().alpha(0f).setDuration(350).withEndAction(() -> offline.setVisibility(View.GONE)).start();
            if (!first) SoundFx.play(this, SoundFx.ONLINE);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        updateNet();
        netCb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { main.post(() -> updateNet()); }
            @Override public void onLost(Network n) { main.post(() -> updateNet()); }
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities c) { main.post(() -> updateNet()); }
        };
        try { cm.registerDefaultNetworkCallback(netCb); } catch (Exception ignored) { }
    }

    @Override protected void onStop() {
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Prefs.theme(this) != themeAtCreate) { recreate(); return; }
        amharic = Prefs.amharic(this);
        langChip.setText(amharic ? "አማ" : "EN");
        applyTts();
    }

    @Override
    protected void onDestroy() {
        CloudTts.stop();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        io.shutdown();
        super.onDestroy();
    }
}
