package com.mubarek.ai;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private GlowOrbView orb;
    private TextView status, reply;
    private EditText input;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final JSONArray history = new JSONArray();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        orb = findViewById(R.id.glowOrb);
        status = findViewById(R.id.status);
        reply = findViewById(R.id.reply);
        input = findViewById(R.id.input);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { main.post(() -> orb.setState(GlowOrbView.State.SPEAKING)); }
                    @Override public void onDone(String id) { main.post(() -> { orb.setState(GlowOrbView.State.IDLE); status.setText("Tap the mic and talk"); }); }
                    @Override public void onError(String id) { main.post(() -> orb.setState(GlowOrbView.State.IDLE)); }
                });
                ttsReady = true;
            }
        });

        findViewById(R.id.btnMic).setOnClickListener(v -> startListening());
        findViewById(R.id.btnSend).setOnClickListener(v -> sendTyped());
        findViewById(R.id.btnAbout).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setMessage(R.string.about_text)
                        .setPositiveButton("OK", null)
                        .show());
        input.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendTyped(); return true; }
            return false;
        });
    }

    private void sendTyped() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        ask(text);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech recognition is not available on this phone");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        if (tts != null) tts.stop();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizer.startListening(i);
        orb.setState(GlowOrbView.State.LISTENING);
        status.setText("Listening…");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else status.setText("Microphone permission is needed to talk");
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rms) { orb.setVoiceRms(rms); }
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() { status.setText("Thinking…"); }
        @Override public void onError(int e) {
            orb.setState(GlowOrbView.State.IDLE);
            status.setText("Didn't catch that. Tap the mic and try again");
        }
        @Override public void onResults(Bundle r) {
            ArrayList<String> list = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) ask(list.get(0));
            else orb.setState(GlowOrbView.State.IDLE);
        }
        @Override public void onPartialResults(Bundle p) {}
        @Override public void onEvent(int t, Bundle p) {}
    };

    private void ask(String text) {
        status.setText("Thinking…");
        orb.setState(GlowOrbView.State.IDLE);
        reply.setText("You: " + text);
        final String body;
        try {
            history.put(new JSONObject().put("role", "user")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", text))));
            JSONObject sys = new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text",
                    "You are Muba-Obama AI, a friendly voice assistant. Keep answers short and easy to say out loud.")));
            body = new JSONObject().put("system_instruction", sys).put("contents", history).toString();
        } catch (Exception e) { status.setText("Error: " + e.getMessage()); return; }

        io.execute(() -> {
            String out;
            boolean ok = true;
            try { out = callGemini(body); }
            catch (Exception e) { out = e.getMessage(); ok = false; }
            final String result = out;
            final boolean success = ok;
            main.post(() -> showReply(result, success));
        });
    }

    private static final String[] MODELS = {
            "gemini-3.8-flash", "gemini-3.1-flash-lite", "gemini-3-flash-preview"};

    /** Tries each model; if one is busy (503/429) or unavailable (404), tries the next, then retries once. */
    private String callGemini(String body) throws Exception {
        Exception last = null;
        for (int round = 0; round < 2; round++) {
            for (String m : MODELS) {
                try { return callGeminiModel(m, body); }
                catch (RetryableException e) { last = e; }
            }
            try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
        }
        throw new Exception(last == null ? "AI is busy. Try again in a moment." : last.getMessage());
    }

    private static class RetryableException extends Exception {
        RetryableException(String m) { super(m); }
    }

    private String callGeminiModel(String model, String body) throws Exception {
        String key = getString(R.string.gemini_key);
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        if (code != 200) {
            String msg = "";
            try { msg = new JSONObject(sb.toString()).getJSONObject("error").getString("message"); } catch (Exception ignored) {}
            if (code == 503 || code == 429 || code == 404 || code == 500)
                throw new RetryableException("Error " + code + ": " + msg);
            throw new Exception("Error " + code + ": " + msg);
        }
        try {
            return new JSONObject(sb.toString()).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
        } catch (Exception e) {
            throw new Exception("The AI gave no answer. Try asking again.");
        }
    }

    private void showReply(String text, boolean ok) {
        if (!ok) {
            if (history.length() > 0) history.remove(history.length() - 1);
            reply.setText(text);
            status.setText("Tap the mic and talk");
            orb.setState(GlowOrbView.State.IDLE);
            return;
        }
        try { history.put(new JSONObject().put("role", "model")
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)))); } catch (Exception ignored) {}
        reply.setText(text);
        status.setText("Speaking…");
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply");
        else { orb.setState(GlowOrbView.State.IDLE); status.setText("Tap the mic and talk"); }
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        io.shutdown();
        super.onDestroy();
    }
}
