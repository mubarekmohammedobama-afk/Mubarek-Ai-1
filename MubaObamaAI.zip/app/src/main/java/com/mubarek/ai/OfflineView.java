package com.mubarek.ai;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Animated "no internet" screen: wifi bars light up and pulse. */
public class OfflineView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Pal pal;
    private final ValueAnimator anim;
    private float phase;

    public OfflineView(Context c) {
        super(c);
        pal = Pal.get(c);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(2400);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { phase = (float) a.getAnimatedValue(); invalidate(); }
        });
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); anim.start(); }
    @Override protected void onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow(); }

    private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }

    @Override protected void onDraw(Canvas c) {
        c.drawColor((pal.bg & 0x00FFFFFF) | 0xF4000000);
        float cx = getWidth() / 2f, cy = getHeight() * 0.36f;
        float u = Math.min(getWidth(), getHeight()) * 0.12f;
        float dotY = cy + u * 0.9f;

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        for (int i = 0; i < 2; i++) {
            float q = (phase + i * 0.5f) % 1f;
            p.setColor(pal.accent);
            p.setAlpha((int) (100 * (1f - q)));
            c.drawCircle(cx, cy, u * (1.8f + q * 2.4f), p);
        }

        p.setStrokeWidth(u * 0.28f);
        p.setStrokeCap(Paint.Cap.ROUND);
        int lit = (int) (phase * 4) % 4;
        for (int i = 0; i < 3; i++) {
            float r = u * (1.0f + i * 0.9f);
            p.setColor(pal.text);
            p.setAlpha(i < lit ? 255 : 70);
            rf.set(cx - r, dotY - r, cx + r, dotY + r);
            c.drawArc(rf, 225, 90, false, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(pal.text);
        p.setAlpha(255);
        c.drawCircle(cx, dotY, u * 0.2f, p);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(u * 0.22f);
        p.setColor(0xFFFF5A5F);
        c.drawLine(cx - u * 1.7f, cy - u * 1.6f, cx + u * 1.7f, cy + u * 1.8f, p);

        tp.setTextAlign(Paint.Align.CENTER);
        tp.setFakeBoldText(true);
        tp.setColor(pal.text);
        tp.setTextSize(sp(22));
        float ty = cy + u * 4.2f;
        c.drawText("No internet connection", cx, ty, tp);
        tp.setFakeBoldText(false);
        tp.setColor(pal.sub);
        tp.setTextSize(sp(15));
        c.drawText("Waiting for the network to come back", cx, ty + sp(30), tp);

        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 3; i++) {
            float q = (phase * 3 + (2 - i)) % 3f;
            p.setColor(pal.accent);
            p.setAlpha(q < 1f ? 255 : 80);
            c.drawCircle(cx + (i - 1) * u * 0.55f, ty + sp(58), u * 0.14f, p);
        }
    }
}
