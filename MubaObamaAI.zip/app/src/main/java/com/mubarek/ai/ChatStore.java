package com.mubarek.ai;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** Saves chat history on the phone. */
final class ChatStore {
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("history", Context.MODE_PRIVATE); }

    static JSONArray all(Context c) {
        try { return new JSONArray(sp(c).getString("convs", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    static void save(Context c, String id, String title, List<Msg> msgs) {
        try {
            JSONArray old = all(c);
            JSONArray out = new JSONArray();
            JSONObject conv = new JSONObject();
            conv.put("id", id);
            conv.put("title", title);
            conv.put("time", System.currentTimeMillis());
            JSONArray ms = new JSONArray();
            for (Msg m : msgs) {
                if (m.skip) continue;
                ms.put(new JSONObject().put("u", m.user).put("t", m.text));
            }
            conv.put("msgs", ms);
            out.put(conv);
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.getJSONObject(i);
                if (!id.equals(o.getString("id"))) out.put(o);
            }
            while (out.length() > 60) out.remove(out.length() - 1);
            sp(c).edit().putString("convs", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    static JSONObject get(Context c, String id) {
        try {
            JSONArray a = all(c);
            for (int i = 0; i < a.length(); i++) {
                if (id.equals(a.getJSONObject(i).getString("id"))) return a.getJSONObject(i);
            }
        } catch (Exception ignored) { }
        return null;
    }

    static void delete(Context c, String id) {
        try {
            JSONArray old = all(c), out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                if (!id.equals(old.getJSONObject(i).getString("id"))) out.put(old.getJSONObject(i));
            }
            sp(c).edit().putString("convs", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void clear(Context c) { sp(c).edit().remove("convs").apply(); }
}
