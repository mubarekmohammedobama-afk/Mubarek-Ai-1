package com.mubarek.ai;

import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {
    private static final String EMAIL = "mubarekmohammedobama@gmail.com";
    private static final String PHONE = "0916765008";

    private Pal pal;
    private LinearLayout card;
    private ImageView photo;
    private TextView nameTv;

    private int dp(float v) { return UI.dp(this, v); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pal = Pal.get(this);
        UI.window(this, pal);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(pal.bg);
        root.setFitsSystemWindows(true);
        root.addView(UI.topBar(this, "More info", pal));

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(8), dp(20), dp(32));
        sv.addView(col);
        root.addView(sv, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));

        // Stage passes touches through, and tilts the card toward your finger.
        FrameLayout stage = new FrameLayout(this) {
            @Override public boolean dispatchTouchEvent(MotionEvent ev) {
                tilt(ev);
                return super.dispatchTouchEvent(ev);
            }
        };
        stage.setPadding(dp(8), dp(16), dp(8), dp(24));
        col.addView(stage, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(28), dp(22), dp(24));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{pal.accent, darker(pal.accent)});
        bg.setCornerRadius(dp(28));
        card.setBackground(bg);
        card.setElevation(dp(16));
        card.setCameraDistance(9000f * getResources().getDisplayMetrics().density);
        stage.addView(card, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));

        photo = new ImageView(this);
        photo.setImageResource(R.drawable.profile_photo);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(0xFF000000);
        ring.setStroke(dp(3), 0xFFFFFFFF);
        photo.setBackground(ring);
        photo.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        photo.setClipToOutline(true);
        photo.setElevation(dp(8));
        card.addView(photo, new LinearLayout.LayoutParams(dp(108), dp(108)));

        nameTv = UI.tv(this, "Mubarek Mohammed Hamza", 22, 0xFFFFFFFF, true);
        nameTv.setGravity(Gravity.CENTER);
        card.addView(nameTv, UI.lp(this, UI.WRAP, UI.WRAP, 0, 16, 0, 2));
        TextView role = UI.tv(this, "Developer · Muba-Obama AI", 14, 0xCCFFFFFF, false);
        card.addView(role);

        View line = new View(this);
        line.setBackgroundColor(0x33FFFFFF);
        card.addView(line, UI.lp(this, UI.MATCH, 1, 0, 20, 0, 12));

        card.addView(contactRow("✉", "Email", EMAIL, v -> {
            Intent it = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + EMAIL));
            try { startActivity(it); } catch (Exception e) { copy(EMAIL); }
        }, EMAIL));
        card.addView(contactRow("☎", "Phone", PHONE, v -> {
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + PHONE))); }
            catch (Exception e) { copy(PHONE); }
        }, PHONE));

        LinearLayout actions = new LinearLayout(this);
        TextView mail = UI.button(this, "Send email", 0xFFFFFFFF, darker(pal.accent));
        mail.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + EMAIL))); }
            catch (Exception e) { copy(EMAIL); }
        });
        TextView call = UI.button(this, "Call now", 0x33FFFFFF, 0xFFFFFFFF);
        call.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + PHONE))); }
            catch (Exception e) { copy(PHONE); }
        });
        actions.addView(mail, UI.lp(this, 0, UI.WRAP, 0, 0, 6, 0));
        actions.addView(call, UI.lp(this, 0, UI.WRAP, 6, 0, 0, 0));
        ((LinearLayout.LayoutParams) mail.getLayoutParams()).weight = 1f;
        ((LinearLayout.LayoutParams) call.getLayoutParams()).weight = 1f;
        card.addView(actions, UI.lp(this, UI.MATCH, UI.WRAP, 0, 16, 0, 0));

        ObjectAnimator float1 = ObjectAnimator.ofFloat(card, "translationY", -dp(6), dp(6));
        float1.setDuration(2400);
        float1.setRepeatMode(ObjectAnimator.REVERSE);
        float1.setRepeatCount(ObjectAnimator.INFINITE);
        float1.setInterpolator(new AccelerateDecelerateInterpolator());
        float1.start();

        // About the app
        LinearLayout about = new LinearLayout(this);
        about.setOrientation(LinearLayout.VERTICAL);
        about.setBackground(UI.rect(this, pal.card, 20));
        about.setPadding(dp(20), dp(18), dp(20), dp(18));
        about.addView(UI.tv(this, "About the app", 18, pal.text, true));
        about.addView(UI.tv(this,
                "Muba-Obama AI is a voice assistant that talks with you in English and Amharic. "
                        + "Speak or type, and it answers out loud with a glowing voice orb.\n\n"
                        + "• Voice and text chat\n• English and Amharic\n• Chat history\n"
                        + "• Themes, voices and sound effects\n• Works with a smart offline screen",
                15, pal.sub, false), UI.lp(this, UI.WRAP, UI.WRAP, 0, 8, 0, 0));
        about.addView(UI.tv(this, "Version 2.0", 13, pal.sub, true), UI.lp(this, UI.WRAP, UI.WRAP, 0, 14, 0, 0));
        col.addView(about, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));

        TextView foot = UI.tv(this, "© Mubarek Mohammed Hamza", 12, pal.sub, false);
        foot.setGravity(Gravity.CENTER);
        col.addView(foot, UI.lp(this, UI.MATCH, UI.WRAP, 0, 16, 0, 0));

        setContentView(root);
    }

    private static int darker(int c) {
        int r = (int) (((c >> 16) & 0xFF) * 0.55f), g = (int) (((c >> 8) & 0xFF) * 0.55f), b = (int) ((c & 0xFF) * 0.55f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private View contactRow(String glyph, String label, String value, View.OnClickListener click, final String copyText) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        row.setClickable(true);
        row.setOnClickListener(click);
        row.setOnLongClickListener(v -> { copy(copyText); return true; });

        TextView icon = UI.tv(this, glyph, 20, 0xFFFFFFFF, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(UI.rect(this, 0x33FFFFFF, 14));
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(UI.tv(this, label, 12, 0xB3FFFFFF, false));
        txt.addView(UI.tv(this, value, 16, 0xFFFFFFFF, true));
        row.addView(txt, UI.lp(this, UI.WRAP, UI.WRAP, 14, 0, 0, 0));
        return row;
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("contact", s));
        Toast.makeText(this, "Copied: " + s, Toast.LENGTH_SHORT).show();
    }

    /** 3D tilt: the card, photo and name move at different depths. */
    private void tilt(MotionEvent ev) {
        if (card == null) return;
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            card.animate().rotationX(0).rotationY(0).setDuration(450).setInterpolator(new OvershootInterpolator()).start();
            photo.animate().translationX(0).translationY(0).setDuration(450).start();
            nameTv.animate().translationX(0).translationY(0).setDuration(450).start();
            return;
        }
        int[] loc = new int[2];
        card.getLocationOnScreen(loc);
        float w = Math.max(1, card.getWidth()), h = Math.max(1, card.getHeight());
        float dx = ((ev.getRawX() - loc[0]) - w / 2f) / (w / 2f);
        float dy = ((ev.getRawY() - loc[1]) - h / 2f) / (h / 2f);
        dx = Math.max(-1f, Math.min(1f, dx));
        dy = Math.max(-1f, Math.min(1f, dy));
        card.animate().cancel();
        card.setRotationY(dx * 14f);
        card.setRotationX(-dy * 14f);
        photo.setTranslationX(dx * dp(9));
        photo.setTranslationY(dy * dp(9));
        nameTv.setTranslationX(dx * dp(4));
        nameTv.setTranslationY(dy * dp(4));
    }
}
