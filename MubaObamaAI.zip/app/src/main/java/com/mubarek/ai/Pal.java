package com.mubarek.ai;

import android.content.Context;

/** Color palette for the 4 themes. */
final class Pal {
    static final String[] NAMES = {"Midnight", "Light", "Ocean", "Sunset"};
    final int bg, card, text, sub, accent;
    final boolean light;

    private Pal(int bg, int card, int text, int sub, int accent, boolean light) {
        this.bg = bg; this.card = card; this.text = text; this.sub = sub; this.accent = accent; this.light = light;
    }

    static Pal get(Context c) {
        switch (Prefs.theme(c)) {
            case 1: return new Pal(0xFFF6F6FA, 0xFFFFFFFF, 0xFF15151F, 0xFF6A6A7A, 0xFF6C5CE7, true);
            case 2: return new Pal(0xFF06121F, 0xFF0D2238, 0xFFFFFFFF, 0xFF9DB7D1, 0xFF2EA8FF, false);
            case 3: return new Pal(0xFF140A0A, 0xFF2A1512, 0xFFFFFFFF, 0xFFD1B0A6, 0xFFFF8A3D, false);
            default: return new Pal(0xFF0B0B12, 0xFF171726, 0xFFFFFFFF, 0xFFB9B9C8, 0xFF8E7CFF, false);
        }
    }
}
