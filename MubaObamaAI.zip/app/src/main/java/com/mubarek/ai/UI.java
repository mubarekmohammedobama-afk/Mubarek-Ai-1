package com.mubarek.ai;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.view.WindowInsetsControllerCompat;

final class UI {
    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView button(Context c, String s, int bg, int fg) {
        TextView t = tv(c, s, 16, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(rect(c, bg, 14));
        int p = dp(c, 14);
        t.setPadding(p, p, p, p);
        t.setClickable(true);
        return t;
    }

    static EditText field(Context c, Pal p, String hint, boolean password) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(p.sub);
        e.setTextColor(p.text);
        e.setSingleLine(true);
        e.setBackground(rect(c, p.card, 14));
        e.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        e.setInputType(password
                ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static void window(Activity a, Pal p) {
        Window w = a.getWindow();
        w.setStatusBarColor(p.bg);
        w.setNavigationBarColor(p.bg);
        WindowInsetsControllerCompat ic = new WindowInsetsControllerCompat(w, w.getDecorView());
        ic.setAppearanceLightStatusBars(p.light);
        ic.setAppearanceLightNavigationBars(p.light);
    }

    /** Back arrow + title bar used by sub pages. */
    static LinearLayout topBar(final Activity a, String title, Pal p) {
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(a, 56)));
        TextView back = tv(a, "←", 26, p.text, true);
        back.setGravity(Gravity.CENTER);
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { a.finish(); }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(a, 56), MATCH));
        bar.addView(tv(a, title, 20, p.text, true));
        return bar;
    }
}
