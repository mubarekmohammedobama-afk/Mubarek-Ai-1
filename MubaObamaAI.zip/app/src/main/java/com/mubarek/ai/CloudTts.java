package com.mubarek.ai;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Online voice (Gemini text-to-speech). Used for Amharic when the phone has no Amharic voice. */
final class CloudTts {
    interface Listener {
        void onStart();
        void onDone(boolean ok, String error);
    }

    private static final String[] MODELS = {"gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts"};
    private static MediaPlayer player;

    static synchronized void stop() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    static void speak(Context ctx, String text, String apiKey, Listener l) { speak(ctx, text, apiKey, l, null); }

    /** With a cacheKey, the audio is saved on the phone and replayed instantly next time. */
    static void speak(final Context ctx, final String text, final String apiKey, final Listener l, final String cacheKey) {
        final Context app = ctx.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final File f = new File(app.getCacheDir(), cacheKey != null ? "cloud_" + cacheKey + ".wav" : "cloud_tts.wav");
                    if (cacheKey == null || !f.exists() || f.length() == 0) {
                        byte[] wav = null;
                        Exception last = null;
                        for (String m : MODELS) {
                            try { wav = fetch(m, text, apiKey); break; }
                            catch (Exception e) { last = e; }
                        }
                        if (wav == null) throw last != null ? last : new Exception("No audio");
                        try (FileOutputStream fo = new FileOutputStream(f)) { fo.write(wav); }
                    }
                    main.post(new Runnable() { @Override public void run() { play(f, l); } });
                } catch (final Exception e) {
                    main.post(new Runnable() { @Override public void run() { l.onDone(false, e.getMessage()); } });
                }
            }
        }).start();
    }

    private static void play(File f, final Listener l) {
        stop();
        try {
            MediaPlayer mp = new MediaPlayer();
            synchronized (CloudTts.class) { player = mp; }
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer m) { l.onStart(); m.start(); }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer m) { stop(); l.onDone(true, null); }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer m, int what, int extra) {
                    stop(); l.onDone(false, "Audio playback error"); return true;
                }
            });
            mp.prepareAsync();
        } catch (Exception e) {
            l.onDone(false, e.getMessage());
        }
    }

    private static byte[] fetch(String model, String text, String key) throws Exception {
        JSONObject ann = new JSONObject().put("type", "speech_metadata").put("style", "warm and friendly");
        JSONObject content = new JSONObject().put("type", "text").put("text", text)
                .put("annotations", new JSONArray().put(ann));
        JSONObject input = new JSONObject().put("type", "user_input").put("content", new JSONArray().put(content));
        JSONObject body = new JSONObject()
                .put("model", model)
                .put("input", new JSONArray().put(input))
                .put("response_format", new JSONObject().put("type", "audio"))
                .put("generation_config", new JSONObject().put("speech_config",
                        new JSONArray().put(new JSONObject().put("voice", "Kore"))));

        HttpURLConnection c = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(90000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        if (code != 200) {
            String msg = "";
            try { msg = new JSONObject(sb.toString()).getJSONObject("error").getString("message"); } catch (Exception ignored) { }
            throw new Exception("Error " + code + (msg.isEmpty() ? "" : ": " + msg));
        }
        String data = findAudio(new JSONObject(sb.toString()));
        if (data == null) throw new Exception("The voice server returned no audio");
        return Base64.decode(data, Base64.DEFAULT);
    }

    /** Finds the last {"type":"audio","data":"..."} anywhere in the response. */
    private static String findAudio(Object node) {
        String found = null;
        try {
            if (node instanceof JSONObject) {
                JSONObject o = (JSONObject) node;
                if ("audio".equals(o.optString("type")) && o.optString("data", "").length() > 0) found = o.getString("data");
                java.util.Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String r = findAudio(o.get(it.next()));
                    if (r != null) found = r;
                }
            } else if (node instanceof JSONArray) {
                JSONArray a = (JSONArray) node;
                for (int i = 0; i < a.length(); i++) {
                    String r = findAudio(a.get(i));
                    if (r != null) found = r;
                }
            }
        } catch (Exception ignored) { }
        return found;
    }
}
