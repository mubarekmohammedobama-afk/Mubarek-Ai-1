package com.mubarek.ai;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Round glowing microphone button. Rings pulse while listening. */
public class MicButton extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private ValueAnimator anim;
    private float phase;
    private boolean active;
    private int accent = 0xFF8E7CFF;

    public MicButton(Context c) {
        super(c);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(1600);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { phase = (float) a.getAnimatedValue(); invalidate(); }
        });
    }

    public void setAccent(int a) { accent = a; invalidate(); }
    public void setActive(boolean a) { active = a; invalidate(); }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); anim.start(); }
    @Override protected void onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow(); }

    @Override protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(getWidth(), getHeight()) / 2f * 0.62f;
        float breathe = 1f + 0.03f * (float) Math.sin(phase * 2 * Math.PI);
        if (active) {
            for (int i = 0; i < 2; i++) {
                float q = (phase + i * 0.5f) % 1f;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.12f);
                p.setColor(accent);
                p.setAlpha((int) (140 * (1f - q)));
                c.drawCircle(cx, cy, r * (1f + q * 0.55f), p);
            }
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(accent);
        p.setAlpha(60);
        c.drawCircle(cx, cy, r * 1.18f * breathe, p);
        p.setAlpha(255);
        c.drawCircle(cx, cy, r * breathe, p);

        // microphone icon
        p.setColor(0xFFFFFFFF);
        rf.set(cx - r * 0.18f, cy - r * 0.48f, cx + r * 0.18f, cy + r * 0.10f);
        c.drawRoundRect(rf, r * 0.18f, r * 0.18f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.10f);
        p.setStrokeCap(Paint.Cap.ROUND);
        rf.set(cx - r * 0.34f, cy - r * 0.30f, cx + r * 0.34f, cy + r * 0.28f);
        c.drawArc(rf, 0, 180, false, p);
        c.drawLine(cx, cy + r * 0.28f, cx, cy + r * 0.50f, p);
        c.drawLine(cx - r * 0.16f, cy + r * 0.50f, cx + r * 0.16f, cy + r * 0.50f, p);
    }
}
