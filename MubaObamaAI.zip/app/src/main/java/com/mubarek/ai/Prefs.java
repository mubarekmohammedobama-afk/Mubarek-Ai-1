package com.mubarek.ai;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;

final class Prefs {
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("muba", Context.MODE_PRIVATE); }

    static int theme(Context c) { return sp(c).getInt("theme", 0); }
    static void setTheme(Context c, int v) { sp(c).edit().putInt("theme", v).apply(); }
    static boolean sound(Context c) { return sp(c).getBoolean("sound", true); }
    static void setSound(Context c, boolean v) { sp(c).edit().putBoolean("sound", v).apply(); }
    static boolean greet(Context c) { return sp(c).getBoolean("greet", true); }
    static void setGreet(Context c, boolean v) { sp(c).edit().putBoolean("greet", v).apply(); }
    static boolean amharic(Context c) { return sp(c).getBoolean("am", false); }
    static void setAmharic(Context c, boolean v) { sp(c).edit().putBoolean("am", v).apply(); }
    static String voice(Context c) { return sp(c).getString("voice", ""); }
    static void setVoice(Context c, String v) { sp(c).edit().putString("voice", v).apply(); }
    static String gvoice(Context c) { return sp(c).getString("gvoice", "Kore"); }
    static void setGvoice(Context c, String v) { sp(c).edit().putString("gvoice", v).apply(); }
    static float rate(Context c) { return sp(c).getFloat("rate", 1f); }
    static void setRate(Context c, float v) { sp(c).edit().putFloat("rate", v).apply(); }
    static float pitch(Context c) { return sp(c).getFloat("pitch", 1f); }
    static void setPitch(Context c, float v) { sp(c).edit().putFloat("pitch", v).apply(); }

    // Local account: stored only on this phone.
    static boolean loggedIn(Context c) { return sp(c).getBoolean("in", false); }
    static boolean hasAccount(Context c) { return !sp(c).getString("pass", "").isEmpty(); }
    static boolean isGuest(Context c) { return sp(c).getBoolean("guest", false); }
    static String displayName(Context c) {
        if (isGuest(c) || !hasAccount(c)) return "Guest";
        return sp(c).getString("user", "");
    }
    static void createAccount(Context c, String name, String pass) {
        sp(c).edit().putString("user", name).putString("pass", hash(name.toLowerCase() + ":" + pass))
                .putBoolean("in", true).putBoolean("guest", false).apply();
    }
    static boolean signIn(Context c, String name, String pass) {
        SharedPreferences s = sp(c);
        boolean ok = s.getString("user", "").equalsIgnoreCase(name)
                && s.getString("pass", "").equals(hash(name.toLowerCase() + ":" + pass));
        if (ok) s.edit().putBoolean("in", true).putBoolean("guest", false).apply();
        return ok;
    }
    static void guest(Context c) { sp(c).edit().putBoolean("in", true).putBoolean("guest", true).apply(); }
    static void logout(Context c) { sp(c).edit().putBoolean("in", false).apply(); }

    private static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("muba-salt:" + s).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return s; }
    }
}
