package com.mubarek.ai;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private boolean creating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Prefs.loggedIn(this)) { openMain(); return; }

        final Pal pal = Pal.get(this);
        UI.window(this, pal);
        creating = !Prefs.hasAccount(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(pal.bg);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(UI.dp(this, 24), UI.dp(this, 24), UI.dp(this, 24), UI.dp(this, 24));
        sv.addView(col, new ScrollView.LayoutParams(UI.MATCH, UI.WRAP));

        GlowOrbView orb = new GlowOrbView(this, null);
        orb.setAccent(pal.accent);
        col.addView(orb, new LinearLayout.LayoutParams(UI.MATCH, UI.dp(this, 230)));

        TextView title = UI.tv(this, "Muba-Obama AI", 28, pal.text, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title);
        final TextView sub = UI.tv(this, "", 15, pal.sub, false);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub, UI.lp(this, UI.MATCH, UI.WRAP, 0, 4, 0, 20));

        final EditText name = UI.field(this, pal, "Your name", false);
        final EditText pass = UI.field(this, pal, "Password", true);
        col.addView(name, UI.lp(this, UI.MATCH, UI.WRAP, 0, 0, 0, 10));
        col.addView(pass, UI.lp(this, UI.MATCH, UI.WRAP, 0, 0, 0, 16));

        final TextView primary = UI.button(this, "", pal.accent, 0xFFFFFFFF);
        col.addView(primary, UI.lp(this, UI.MATCH, UI.WRAP, 0, 0, 0, 10));
        final TextView toggle = UI.tv(this, "", 14, pal.accent, true);
        toggle.setGravity(Gravity.CENTER);
        toggle.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 10));
        toggle.setClickable(true);
        col.addView(toggle);
        TextView guest = UI.button(this, "Continue as guest", pal.card, pal.text);
        col.addView(guest, UI.lp(this, UI.MATCH, UI.WRAP, 0, 8, 0, 14));
        TextView note = UI.tv(this, "Your account is saved only on this phone.", 12, pal.sub, false);
        note.setGravity(Gravity.CENTER);
        col.addView(note);

        final Runnable refresh = () -> {
            sub.setText(creating ? "Create your account" : "Welcome back");
            primary.setText(creating ? "Create account" : "Sign in");
            toggle.setText(creating
                    ? (Prefs.hasAccount(this) ? "I already have an account" : "")
                    : "Create a new account");
        };
        refresh.run();

        toggle.setOnClickListener(v -> { creating = !creating; refresh.run(); });
        primary.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String p = pass.getText().toString();
            if (n.isEmpty() || p.length() < 4) {
                Toast.makeText(this, "Enter a name and a password of at least 4 characters", Toast.LENGTH_SHORT).show();
                return;
            }
            if (creating) {
                Prefs.createAccount(this, n, p);
                openMain();
            } else if (Prefs.signIn(this, n, p)) {
                openMain();
            } else {
                SoundFx.play(this, SoundFx.ERROR);
                Toast.makeText(this, "Wrong name or password", Toast.LENGTH_SHORT).show();
            }
        });
        guest.setOnClickListener(v -> { Prefs.guest(this); openMain(); });
        setContentView(sv);
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
