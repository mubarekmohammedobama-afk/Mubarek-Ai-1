package com.mubarek.ai;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Soft synthesized sound effects (no audio files needed). */
final class SoundFx {
    static final int START = 0, SEND = 1, REPLY = 2, ERROR = 3, ONLINE = 4;
    private static final int SR = 22050;

    static void play(Context c, final int type) {
        if (!Prefs.sound(c)) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    short[] pcm = synth(type);
                    AudioTrack t = new AudioTrack.Builder()
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                            .setAudioFormat(new AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setSampleRate(SR)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                            .setBufferSizeInBytes(pcm.length * 2)
                            .setTransferMode(AudioTrack.MODE_STATIC).build();
                    t.write(pcm, 0, pcm.length);
                    t.play();
                    Thread.sleep(pcm.length * 1000L / SR + 250);
                    t.release();
                } catch (Exception ignored) { }
            }
        }).start();
    }

    // each note: {frequency Hz, start ms, length ms, volume}
    private static short[] synth(int type) {
        float[][] notes;
        switch (type) {
            case START:  notes = new float[][]{{659.3f, 0, 160, .45f}, {987.8f, 80, 320, .45f}}; break;
            case SEND:   notes = new float[][]{{880f, 0, 70, .40f}, {1318.5f, 35, 120, .35f}}; break;
            case REPLY:  notes = new float[][]{{1046.5f, 0, 170, .30f}, {1318.5f, 70, 170, .30f},
                    {1568f, 140, 180, .30f}, {2093f, 210, 340, .28f}}; break;
            case ERROR:  notes = new float[][]{{392f, 0, 190, .40f}, {293.7f, 110, 340, .40f}}; break;
            default:     notes = new float[][]{{523.3f, 0, 130, .35f}, {659.3f, 70, 130, .35f}, {784f, 140, 280, .35f}};
        }
        int total = 0;
        for (float[] n : notes) total = Math.max(total, (int) ((n[1] + n[2]) * SR / 1000f));
        float[] mix = new float[total];
        for (float[] n : notes) {
            int s0 = (int) (n[1] * SR / 1000f);
            int len = (int) (n[2] * SR / 1000f);
            for (int i = 0; i < len && s0 + i < total; i++) {
                double t = i / (double) SR;
                double env = Math.min(1.0, i / (SR * 0.006)) * Math.exp(-4.5 * i / (double) len)
                        * Math.min(1.0, (len - i) / (SR * 0.01));
                double v = Math.sin(2 * Math.PI * n[0] * t) + 0.3 * Math.sin(4 * Math.PI * n[0] * t)
                        + 0.1 * Math.sin(6 * Math.PI * n[0] * t);
                mix[s0 + i] += (float) (v * env * n[3]);
            }
        }
        short[] out = new short[total];
        for (int i = 0; i < total; i++) {
            float v = Math.max(-1f, Math.min(1f, mix[i]));
            out[i] = (short) (v * 30000);
        }
        return out;
    }
}
