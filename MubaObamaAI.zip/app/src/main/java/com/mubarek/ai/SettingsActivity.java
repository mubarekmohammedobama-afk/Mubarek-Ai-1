package com.mubarek.ai;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class SettingsActivity extends AppCompatActivity {
    private Pal pal;
    private LinearLayout col;
    private TextToSpeech tts;
    private boolean ttsReady;
    private TextView voiceLabel;

    private int dp(float v) { return UI.dp(this, v); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pal = Pal.get(this);
        UI.window(this, pal);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(pal.bg);
        root.setFitsSystemWindows(true);
        root.addView(UI.topBar(this, "Settings", pal));

        ScrollView sv = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), 0, dp(16), dp(32));
        sv.addView(col);
        root.addView(sv, new LinearLayout.LayoutParams(UI.MATCH, 0, 1f));
        setContentView(root);

        tts = new TextToSpeech(this, st -> ttsReady = (st == TextToSpeech.SUCCESS));
        build();
    }

    private void header(String s) {
        TextView t = UI.tv(this, s.toUpperCase(), 12, pal.accent, true);
        t.setLetterSpacing(0.1f);
        col.addView(t, UI.lp(this, UI.WRAP, UI.WRAP, 4, 22, 0, 8));
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(UI.rect(this, pal.card, 16));
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(c, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
        return c;
    }

    private void chips(LinearLayout parent, String[] names, int selected, final IntConsumer pick) {
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean on = i == selected;
            TextView t = UI.tv(this, names[i], 14, on ? 0xFFFFFFFF : pal.text, true);
            t.setGravity(Gravity.CENTER);
            t.setBackground(UI.rect(this, on ? pal.accent : (pal.bg), 12));
            t.setPadding(0, dp(11), 0, dp(11));
            t.setClickable(true);
            t.setOnClickListener(v -> pick.accept(idx));
            row.addView(t, UI.lp(this, 0, UI.WRAP, 3, 0, 3, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        parent.addView(row, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
    }

    private void slider(LinearLayout parent, String label, float cur, final Consumer<Float> save) {
        parent.addView(UI.tv(this, label, 14, pal.sub, false), UI.lp(this, UI.WRAP, UI.WRAP, 0, 12, 0, 0));
        SeekBar sb = new SeekBar(this);
        sb.setMax(100);
        sb.setProgress(Math.round((cur - 0.5f) * 100f));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {}
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { save.accept(0.5f + s.getProgress() / 100f); }
        });
        parent.addView(sb, new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
    }

    private void build() {
        header("Account");
        LinearLayout a = card();
        a.addView(UI.tv(this, "Signed in as " + Prefs.displayName(this), 16, pal.text, true));
        TextView logout = UI.button(this, "Log out", pal.bg, pal.text);
        logout.setOnClickListener(v -> {
            Prefs.logout(this);
            Intent it = new Intent(this, LoginActivity.class);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(it);
        });
        a.addView(logout, UI.lp(this, UI.MATCH, UI.WRAP, 0, 12, 0, 0));

        header("Theme");
        chips(card(), Pal.NAMES, Prefs.theme(this), i -> { Prefs.setTheme(this, i); recreate(); });

        header("Language");
        chips(card(), new String[]{"English", "አማርኛ"}, Prefs.amharic(this) ? 1 : 0,
                i -> { Prefs.setAmharic(this, i == 1); recreate(); });

        header("Assistant voice");
        LinearLayout v = card();
        voiceLabel = UI.tv(this, "", 15, pal.text, false);
        v.addView(voiceLabel);
        updateVoiceLabel();
        TextView choose = UI.button(this, "Choose voice", pal.accent, 0xFFFFFFFF);
        choose.setOnClickListener(x -> chooseVoice());
        v.addView(choose, UI.lp(this, UI.MATCH, UI.WRAP, 0, 12, 0, 0));
        TextView test = UI.button(this, "Test voice", pal.bg, pal.text);
        test.setOnClickListener(x -> sample());
        v.addView(test, UI.lp(this, UI.MATCH, UI.WRAP, 0, 8, 0, 0));
        slider(v, "Speed", Prefs.rate(this), f -> Prefs.setRate(this, f));
        slider(v, "Pitch", Prefs.pitch(this), f -> Prefs.setPitch(this, f));

        header("Sound");
        LinearLayout s = card();
        SwitchCompat sw = new SwitchCompat(this);
        sw.setText("Sound effects");
        sw.setTextColor(pal.text);
        sw.setTextSize(16);
        sw.setChecked(Prefs.sound(this));
        sw.setOnCheckedChangeListener((b, on) -> {
            Prefs.setSound(this, on);
            if (on) SoundFx.play(this, SoundFx.REPLY);
        });
        s.addView(sw);
        SwitchCompat gs = new SwitchCompat(this);
        gs.setText("Voice greeting when I tap the mic");
        gs.setTextColor(pal.text);
        gs.setTextSize(16);
        gs.setChecked(Prefs.greet(this));
        gs.setOnCheckedChangeListener((b, on) -> Prefs.setGreet(this, on));
        s.addView(gs, UI.lp(this, UI.MATCH, UI.WRAP, 0, 14, 0, 0));

        header("Data");
        LinearLayout d = card();
        TextView clear = UI.button(this, "Clear chat history", 0xFFE5484D, 0xFFFFFFFF);
        clear.setOnClickListener(x -> new AlertDialog.Builder(this)
                .setMessage("Delete all saved chats?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dlg, w) -> {
                    ChatStore.clear(this);
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                }).show());
        d.addView(clear);
    }

    private void updateVoiceLabel() {
        String vn = Prefs.voice(this);
        voiceLabel.setText(vn.isEmpty() ? "Current: Default voice" : "Current: custom voice selected");
    }

    private String lang() { return Prefs.amharic(this) ? "am" : Locale.getDefault().getLanguage(); }

    private void chooseVoice() {
        if (!ttsReady) { Toast.makeText(this, "Voices are still loading, try again", Toast.LENGTH_SHORT).show(); return; }
        final List<Voice> list = new ArrayList<>();
        try {
            Set<Voice> all = tts.getVoices();
            if (all != null) for (Voice v : all) if (v.getLocale().getLanguage().equals(lang())) list.add(v);
        } catch (Exception ignored) { }
        Collections.sort(list, (x, y) -> x.getName().compareTo(y.getName()));
        if (list.isEmpty()) {
            Toast.makeText(this, Prefs.amharic(this)
                    ? "Amharic uses the built-in online voice, so there is nothing to choose"
                    : "No voices for this language on your phone", Toast.LENGTH_LONG).show();
            return;
        }
        String[] labels = new String[list.size() + 1];
        labels[0] = "Default voice";
        int checked = 0;
        String cur = Prefs.voice(this);
        for (int i = 0; i < list.size(); i++) {
            Voice v = list.get(i);
            labels[i + 1] = "Voice " + (i + 1) + " · " + v.getLocale().getDisplayCountry()
                    + (v.isNetworkConnectionRequired() ? " (online)" : "");
            if (v.getName().equals(cur)) checked = i + 1;
        }
        new AlertDialog.Builder(this).setTitle("Assistant voice")
                .setSingleChoiceItems(labels, checked, (dlg, which) -> {
                    Prefs.setVoice(this, which == 0 ? "" : list.get(which - 1).getName());
                    dlg.dismiss();
                    updateVoiceLabel();
                    sample();
                }).show();
    }

    private void sample() {
        if (!ttsReady) return;
        boolean am = Prefs.amharic(this);
        int r = tts.setLanguage(am ? new Locale("am", "ET") : Locale.getDefault());
        if (r < 0) {
            CloudTts.speak(this, "ሰላም፣ እኔ ሙባ ኦባማ ኤአይ ነኝ።", getString(R.string.gemini_key), new CloudTts.Listener() {
                @Override public void onStart() {}
                @Override public void onDone(boolean ok, String error) {
                    if (!ok) Toast.makeText(SettingsActivity.this, "Voice error: " + error, Toast.LENGTH_LONG).show();
                }
            });
            return;
        }
        tts.setSpeechRate(Prefs.rate(this));
        tts.setPitch(Prefs.pitch(this));
        String vn = Prefs.voice(this);
        if (!vn.isEmpty()) {
            try {
                for (Voice v : tts.getVoices()) {
                    if (v.getName().equals(vn) && v.getLocale().getLanguage().equals(lang())) { tts.setVoice(v); break; }
                }
            } catch (Exception ignored) { }
        }
        tts.speak(am ? "ሰላም፣ እኔ ሙባ ኦባማ ኤአይ ነኝ።" : "Hello, I'm Muba-Obama AI. How can I help you?",
                TextToSpeech.QUEUE_FLUSH, null, "sample");
    }

    @Override protected void onDestroy() {
        CloudTts.stop();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
