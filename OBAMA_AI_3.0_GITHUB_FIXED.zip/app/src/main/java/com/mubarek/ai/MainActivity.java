package com.mubarek.ai;

import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

public class MainActivity extends AppCompatActivity {
    private Pal pal;
    private GlowOrbView orb;
    private MicButton mic;
    private TextView status, langChip, attachmentChip;
    private EditText input;
    private RecyclerView rv;
    private Adapter adapter;
    private final List<Msg> msgs = new ArrayList<>();
    private String convId;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady, voiceOk, amharic, greeting;
    private Uri pendingUri;
    private String pendingName = "", pendingMime = "";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private int generation = 0;
    private boolean streaming;

    private int dp(float v) { return UI.dp(this, v); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pal = Pal.get(this); amharic = Prefs.amharic(this); UI.window(this, pal);
        convId = getIntent().getStringExtra("conv");
        if (convId != null) loadConversation(); else convId = String.valueOf(System.currentTimeMillis());
        if (msgs.isEmpty()) addWelcome();
        buildUi();
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { main.post(() -> orb.setState(GlowOrbView.State.SPEAKING)); }
                    @Override public void onDone(String id) { main.post(() -> { orb.setState(GlowOrbView.State.IDLE); if (Prefs.voiceMode(this) && "reply".equals(id)) startListening(); }); }
                    @Override public void onError(String id) { main.post(() -> orb.setState(GlowOrbView.State.IDLE)); }
                });
                applyTts();
            }
        });
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(pal.bg); root.setFitsSystemWindows(true);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); root.addView(page, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(12), dp(4), dp(8), dp(4));
        ImageButton menu = icon(android.R.drawable.ic_menu_sort_by_size, v -> startActivity(new Intent(this, HistoryActivity.class)));
        top.addView(menu, new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(dp(8),0,0,0);
        TextView title = UI.tv(this,"OBAMA",19,pal.text,true); brand.addView(title);
        TextView sub = UI.tv(this,"Mubarek voice assistant",11,pal.sub,false); brand.addView(sub);
        top.addView(brand,new LinearLayout.LayoutParams(0,UI.WRAP,1));
        langChip = UI.tv(this,amharic?"አማ":"EN",12,pal.text,true); langChip.setGravity(Gravity.CENTER); langChip.setBackground(UI.rect(this,pal.card,18)); langChip.setPadding(dp(12),dp(7),dp(12),dp(7));
        langChip.setOnClickListener(v -> { amharic=!amharic; Prefs.setAmharic(this,amharic); applyTts(); langChip.setText(amharic?"አማ":"EN"); });
        top.addView(langChip,UI.lp(this,UI.WRAP,UI.WRAP,0,0,6,0));
        top.addView(icon(android.R.drawable.ic_menu_add,v->newChat()),new LinearLayout.LayoutParams(dp(44),dp(44)));
        top.addView(icon(android.R.drawable.ic_menu_preferences,v->startActivity(new Intent(this,SettingsActivity.class))),new LinearLayout.LayoutParams(dp(44),dp(44)));
        page.addView(top,new LinearLayout.LayoutParams(-1,dp(60)));

        orb = new GlowOrbView(this,null); orb.setAccent(pal.accent); page.addView(orb,new LinearLayout.LayoutParams(-1,dp(145)));
        status=UI.tv(this,"Ready when you are",13,pal.sub,false); status.setGravity(Gravity.CENTER); page.addView(status,new LinearLayout.LayoutParams(-1,dp(30)));

        rv=new RecyclerView(this); rv.setLayoutManager(new LinearLayoutManager(this)); rv.setClipToPadding(false); rv.setPadding(dp(6),dp(8),dp(6),dp(10)); adapter=new Adapter(); rv.setAdapter(adapter); page.addView(rv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout composerWrap=new LinearLayout(this); composerWrap.setOrientation(LinearLayout.VERTICAL); composerWrap.setPadding(dp(10),dp(4),dp(10),dp(10));
        attachmentChip=UI.tv(this,"",12,pal.sub,false); attachmentChip.setVisibility(View.GONE); attachmentChip.setGravity(Gravity.CENTER_VERTICAL); attachmentChip.setPadding(dp(12),dp(8),dp(12),dp(8)); attachmentChip.setBackground(UI.rect(this,pal.card,14)); attachmentChip.setOnClickListener(v->clearAttachment()); composerWrap.addView(attachmentChip,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.BOTTOM); bar.setBackground(UI.rect(this,pal.card,28)); bar.setPadding(dp(6),dp(6),dp(6),dp(6));
        ImageButton attach=roundIcon(android.R.drawable.ic_menu_add,v->pickFile()); bar.addView(attach,new LinearLayout.LayoutParams(dp(46),dp(46)));
        input=new EditText(this); input.setHint("Message OBAMA"); input.setHintTextColor(pal.sub); input.setTextColor(pal.text); input.setTextSize(16); input.setMaxLines(5); input.setMinHeight(dp(46)); input.setBackground(null); input.setPadding(dp(8),dp(8),dp(8),dp(8)); input.setGravity(Gravity.CENTER_VERTICAL); input.setImeOptions(EditorInfo.IME_ACTION_SEND); input.setInputType(0x00000001|0x00004000|0x00010000); input.setOnEditorActionListener((v,a,e)->{if(a==EditorInfo.IME_ACTION_SEND){sendTyped();return true;}return false;}); bar.addView(input,new LinearLayout.LayoutParams(0,UI.WRAP,1));
        mic=new MicButton(this); mic.setAccent(pal.accent); mic.setOnClickListener(v->micPressed()); bar.addView(mic,new LinearLayout.LayoutParams(dp(48),dp(48)));
        ImageButton send=roundIcon(android.R.drawable.ic_menu_send,v->sendTyped()); send.setContentDescription("Send message"); bar.addView(send,new LinearLayout.LayoutParams(dp(46),dp(46)));
        composerWrap.addView(bar,new LinearLayout.LayoutParams(-1,dp(58))); page.addView(composerWrap,new LinearLayout.LayoutParams(-1,UI.WRAP));
        setContentView(root);
    }

    private ImageButton icon(int res,View.OnClickListener l){ImageButton b=new ImageButton(this);b.setImageResource(res);b.setColorFilter(pal.text);b.setBackground(null);b.setOnClickListener(l);b.setContentDescription("OBAMA");return b;}
    private ImageButton roundIcon(int res,View.OnClickListener l){ImageButton b=icon(res,l);GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(pal.accent);b.setBackground(g);b.setColorFilter(0xFFFFFFFF);return b;}

    private class Adapter extends RecyclerView.Adapter<Adapter.VH>{
        class VH extends RecyclerView.ViewHolder{LinearLayout box;TextView bubble,actions;VH(LinearLayout b,TextView t,TextView a){super(b);box=b;bubble=t;actions=a;}}
        @Override public VH onCreateViewHolder(ViewGroup p,int type){LinearLayout box=new LinearLayout(MainActivity.this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(8),dp(5),dp(8),dp(5));TextView t=UI.tv(MainActivity.this,"",16,pal.text,false);t.setPadding(dp(15),dp(12),dp(15),dp(12));t.setLineSpacing(0,1.08f);TextView a=UI.tv(MainActivity.this,"",11,pal.sub,false);a.setPadding(dp(8),dp(2),dp(8),0);box.addView(t,new LinearLayout.LayoutParams(UI.WRAP,UI.WRAP));box.addView(a,new LinearLayout.LayoutParams(UI.WRAP,UI.WRAP));return new VH(box,t,a);}
        @Override public void onBindViewHolder(VH h,int pos){Msg m=msgs.get(pos);h.bubble.setText(m.text);h.actions.setVisibility(m.user||m.skip?View.GONE:View.VISIBLE);h.actions.setText("Copy   •   Speak   •   Regenerate");h.actions.setOnClickListener(v->showActions(pos));h.bubble.setBackground(UI.rect(MainActivity.this,m.user?pal.accent:pal.card,20));h.bubble.setTextColor(m.user?0xFFFFFFFF:pal.text);LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)h.bubble.getLayoutParams();lp.gravity=m.user?Gravity.END:Gravity.START;h.bubble.setLayoutParams(lp);}
        @Override public int getItemCount(){return msgs.size();}
    }

    private void showActions(int pos){if(pos<0||pos>=msgs.size())return;Msg m=msgs.get(pos);new androidx.appcompat.app.AlertDialog.Builder(this).setItems(new String[]{"Copy response","Speak response","Regenerate"},(d,w)->{if(w==0){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("OBAMA",m.text));Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show();}else if(w==1)speakText(m.text,false);else regenerate();}).show();}
    private void scrollEnd(){if(!msgs.isEmpty())rv.scrollToPosition(msgs.size()-1);}

    private void loadConversation(){JSONObject c=ChatStore.get(this,convId);if(c==null)return;try{JSONArray a=c.getJSONArray("msgs");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);msgs.add(new Msg(o.getBoolean("u"),o.getString("t")));}}catch(Exception ignored){}}
    private void newChat(){stopGeneration();msgs.clear();convId=String.valueOf(System.currentTimeMillis());addWelcome();adapter.notifyDataSetChanged();status.setText("New conversation");scrollEnd();}

    private void addWelcome(){String n=Prefs.displayName(this);boolean named=!n.equals("Guest")&&!n.isEmpty();String t=amharic?"ሰላም"+(named?" "+n:"")+"! እኔ ሙባሬክ ነኝ፣ የOBAMA የድምጽ ረዳት። ጥያቄ ይጠይቁኝ፣ ፋይል ያያይዙ ወይም ማይኩን ተጭነው ይናገሩ።":"Hi"+(named?" "+n:"")+"! I'm Mubarek, the voice assistant behind OBAMA. Ask me anything, attach a file, or tap the microphone and talk.";Msg w=new Msg(false,t);w.skip=true;msgs.add(w);}

    private void applyTts(){if(!ttsReady)return;tts.setSpeechRate(Prefs.rate(this));tts.setPitch(Prefs.pitch(this));voiceOk=true;Locale loc=amharic?new Locale("am","ET"):Locale.getDefault();int r=tts.setLanguage(loc);if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED){voiceOk=false;return;}String vn=Prefs.voice(this);if(!vn.isEmpty())try{for(android.speech.tts.Voice v:tts.getVoices())if(v.getName().equals(vn)&&v.getLocale().getLanguage().equals(loc.getLanguage())){tts.setVoice(v);break;}}catch(Exception ignored){}}

    private void micPressed(){if(greeting){greeting=false;if(tts!=null)tts.stop();CloudTts.stop();startListening();return;}String[] g=amharic?new String[]{"ሰላም! ሙባሬክ እያዳመጠ ነው። እንጀምር።","እንኳን ደህና መጡ። ምን ልርዳዎት?"}:new String[]{"Hi, I'm Mubarek. I'm listening.","Welcome to OBAMA. Go ahead, I'm listening.","Hello! Mubarek here. What can I help you with?"};String text=g[(int)(Math.random()*g.length)];greeting=true;if(Prefs.greet(this)){speakText(text,true);}else{greeting=false;startListening();}}
    private void speakText(String text,boolean thenListen){if(ttsReady&&voiceOk&&!Prefs.cloudVoice(this)){greeting=thenListen;tts.speak(clean(text),TextToSpeech.QUEUE_FLUSH,null,thenListen?"greet":"reply");return;}VoiceProfile v=VoiceProfile.get(Prefs.voiceProfile(this));CloudTts.speak(this,clean(text),BuildConfig.GEMINI_API_KEY,v.cloudVoice,v.style,new CloudTts.Listener(){public void onStart(){orb.setState(GlowOrbView.State.SPEAKING);status.setText("Speaking…");}public void onDone(boolean ok,String err){orb.setState(GlowOrbView.State.IDLE);if(thenListen&&greeting){greeting=false;startListening();}else status.setText(ok?"Ready when you are":"Voice unavailable: "+err);}});}
    private String clean(String s){return s.replace("*","").replace("#","").trim();}

    private void startListening(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7);return;}if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("Speech recognition is not available on this phone");return;}if(recognizer==null){recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(listener);}if(tts!=null)tts.stop();CloudTts.stop();Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,amharic?"am-ET":Locale.getDefault().toLanguageTag());recognizer.startListening(i);mic.setActive(true);orb.setState(GlowOrbView.State.LISTENING);status.setText("Listening…");}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startListening();else status.setText("Microphone permission is needed");}
    private final RecognitionListener listener=new RecognitionListener(){public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float rms){orb.setVoiceRms(rms);}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){mic.setActive(false);status.setText("Thinking…");}public void onError(int e){mic.setActive(false);orb.setState(GlowOrbView.State.IDLE);status.setText("I didn't catch that. Try again.");}public void onResults(Bundle r){mic.setActive(false);ArrayList<String> a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())submit(a.get(0),true);else orb.setState(GlowOrbView.State.IDLE);}public void onPartialResults(Bundle b){}public void onEvent(int t,Bundle b){}};

    private void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);startActivityForResult(i,44);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=44||c!=RESULT_OK||d==null)return;Uri u=d.getData();if(u==null&&d.getClipData()!=null)u=d.getClipData().getItemAt(0).getUri();if(u==null)return;try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}pendingUri=u;pendingName=queryName(u);pendingMime=getContentResolver().getType(u);if(pendingMime==null)pendingMime="application/octet-stream";attachmentChip.setText("📎  "+pendingName+"   •   tap to remove");attachmentChip.setVisibility(View.VISIBLE);}
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "Attached file";}
    private void clearAttachment(){pendingUri=null;pendingName="";pendingMime="";attachmentChip.setVisibility(View.GONE);}

    private void sendTyped(){String t=input.getText().toString().trim();if(t.isEmpty()&&pendingUri==null)return;input.setText("");submit(t.isEmpty()?"Please analyze the attached file.":t,true);}
    private void regenerate(){String last=null;for(int i=msgs.size()-1;i>=0;i--)if(msgs.get(i).user&&!msgs.get(i).skip){last=msgs.get(i).text;break;}if(last!=null)submit(last,false);}

    private void submit(String text,boolean addUser){if(!isOnline()){status.setText("No internet connection");return;}final Attachment att=readPendingAttachment();if(att.error!=null){Toast.makeText(this,att.error,Toast.LENGTH_LONG).show();return;}clearAttachment();if(addUser){msgs.add(new Msg(true,text));}final String body;try{body=buildBody(text,att);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return;}final Msg answer=new Msg(false,"Thinking…");msgs.add(answer);adapter.notifyDataSetChanged();scrollEnd();status.setText("Thinking…");orb.setState(GlowOrbView.State.THINKING);stopGeneration();streaming=true;final int my=++generation;io.execute(()->{final boolean[] got={false};try{streamGemini(body,chunk->{got[0]=true;main.post(()->onChunk(answer,chunk,my));});main.post(()->finish(answer,got[0],null,my));}catch(Exception e){main.post(()->finish(answer,got[0],e.getMessage(),my));}});}

    private void onChunk(Msg m,String d,int my){if(my!=generation)return;if("Thinking…".equals(m.text))m.text="";m.text+=d;adapter.notifyItemChanged(msgs.indexOf(m));scrollEnd();status.setText("Mubarek is thinking…");orb.setState(GlowOrbView.State.THINKING);}
    private void finish(Msg answer,boolean ok,String err,int my){if(my!=generation)return;streaming=false;if(!ok){answer.text=err==null?"Something went wrong.":err;adapter.notifyDataSetChanged();status.setText("Ready when you are");orb.setState(GlowOrbView.State.IDLE);return;}ChatStore.save(this,convId,firstUserText(),msgs);adapter.notifyDataSetChanged();scrollEnd();speakText(answer.text,false);}
    private String firstUserText(){for(Msg m:msgs)if(m.user&&!m.skip)return m.text;return "Chat";}

    private void stopGeneration(){generation++;streaming=false;if(tts!=null)tts.stop();CloudTts.stop();if(mic!=null)mic.setActive(false);if(orb!=null)orb.setState(GlowOrbView.State.IDLE);}

    private static class Attachment{String mime,name;byte[] data;String error;}
    private Attachment readPendingAttachment(){Attachment a=new Attachment();if(pendingUri==null)return a;a.mime=pendingMime;a.name=pendingName;try{long len=-1;try(android.database.Cursor c=getContentResolver().query(pendingUri,new String[]{OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0))len=c.getLong(0);}if(len>7*1024*1024){a.error="That file is larger than 7 MB. Please choose a smaller file.";return a;}try(InputStream in=getContentResolver().openInputStream(pendingUri)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>7*1024*1024){a.error="That file is larger than 7 MB.";return a;}}a.data=out.toByteArray();}}catch(Exception e){a.error="Couldn't read the attachment: "+e.getMessage();}return a;}

    private String buildBody(String current,Attachment att)throws Exception{JSONArray contents=new JSONArray();int start=Math.max(0,msgs.size()-20);for(int i=start;i<msgs.size();i++){Msg m=msgs.get(i);if(m.skip)continue;if(att.data!=null&&i==msgs.size()-1&&m.user)continue;if(!m.user&&i==msgs.size()-1)continue;JSONObject part=new JSONObject().put("text",m.text);contents.put(new JSONObject().put("role",m.user?"user":"model").put("parts",new JSONArray().put(part)));}if(att.data!=null){JSONArray parts=new JSONArray().put(new JSONObject().put("text",current));parts.put(new JSONObject().put("inline_data",new JSONObject().put("mime_type",att.mime).put("data",android.util.Base64.encodeToString(att.data,android.util.Base64.NO_WRAP))));contents.put(new JSONObject().put("role","user").put("parts",parts));}else if(!current.isEmpty() && (msgs.isEmpty()||!msgs.get(msgs.size()-1).user||!current.equals(msgs.get(msgs.size()-1).text)||!msgs.get(msgs.size()-1).skip)){contents.put(new JSONObject().put("role","user").put("parts",new JSONArray().put(new JSONObject().put("text",current))));}
        JSONObject sys=new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text", "You are Mubarek, the friendly voice assistant inside an app named OBAMA. Be helpful, accurate and natural. Reply in the user's language. If they use Amharic, answer in Amharic. When speaking aloud, avoid excessive markdown. You can analyze attached files when supplied. Keep conversational answers concise unless the user asks for detail.")));
        return new JSONObject().put("system_instruction",sys).put("contents",contents).toString();}

    private void streamGemini(String body,Consumer<String> cb)throws Exception{String[] models={"gemini-3.8-flash","gemini-3.5-flash-lite","gemini-2.5-flash"};Exception last=null;for(String model:models){try{streamModel(model,body,cb);return;}catch(Exception e){last=e;if(e.getMessage()!=null&&!e.getMessage().contains("404")&&!e.getMessage().contains("429")&&!e.getMessage().contains("503"))throw e;}}throw last==null?new Exception("AI is unavailable."):last;}
    private void streamModel(String model,String body,Consumer<String> cb)throws Exception{if(BuildConfig.GEMINI_API_KEY==null||BuildConfig.GEMINI_API_KEY.isEmpty())throw new Exception("Gemini API key is missing. Add GEMINI_API_KEY to your Gradle properties.");URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/"+model+":streamGenerateContent?alt=sse");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("x-goog-api-key",BuildConfig.GEMINI_API_KEY);try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream is=code>=400?c.getErrorStream():c.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));if(code!=200){StringBuilder e=new StringBuilder();String line;while((line=br.readLine())!=null)e.append(line);throw new Exception("Gemini error "+code+": "+parseError(e.toString()));}String line;while((line=br.readLine())!=null){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(!line.startsWith("data:"))continue;String json=line.substring(5).trim();if(json.isEmpty())continue;try{JSONObject o=new JSONObject(json);JSONArray cand=o.optJSONArray("candidates");if(cand==null||cand.length()==0)continue;JSONArray parts=cand.getJSONObject(0).getJSONObject("content").getJSONArray("parts");for(int i=0;i<parts.length();i++){String t=parts.getJSONObject(i).optString("text","");if(!t.isEmpty())cb.accept(t);}}catch(Exception ignored){}}}
    private String parseError(String s){try{return new JSONObject(s).getJSONObject("error").optString("message",s);}catch(Exception e){return s;}}
    private boolean isOnline(){ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NetworkCapabilities n=cm.getNetworkCapabilities(cm.getActiveNetwork());return n!=null&&(n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||n.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)||n.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));}

    @Override protected void onDestroy(){stopGeneration();if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();io.shutdownNow();super.onDestroy();}
}
