package com.mubarek.ai;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Intro screen: glowing profile, welcome text and a loading animation. */
public class SplashActivity extends AppCompatActivity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView step;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Pal pal = Pal.get(this);
        UI.window(this, pal);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(pal.bg);
        root.setPadding(UI.dp(this, 24), 0, UI.dp(this, 24), 0);

        GlowOrbView orb = new GlowOrbView(this, null);
        orb.setAccent(pal.accent);
        root.addView(orb, new LinearLayout.LayoutParams(UI.MATCH, UI.dp(this, 290)));

        TextView title = UI.tv(this, "OBAMA", 32, pal.text, true);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        title.setTranslationY(UI.dp(this, 24));
        root.addView(title);

        boolean named = Prefs.loggedIn(this) && !Prefs.displayName(this).equals("Guest");
        TextView welcome = UI.tv(this, named ? "Welcome back, " + Prefs.displayName(this) + "!" : "Welcome! Your voice assistant is ready.",
                17, pal.sub, false);
        welcome.setGravity(Gravity.CENTER);
        welcome.setAlpha(0f);
        welcome.setTranslationY(UI.dp(this, 16));
        root.addView(welcome, UI.lp(this, UI.WRAP, UI.WRAP, 0, 8, 0, 28));

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgressTintList(ColorStateList.valueOf(pal.accent));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(pal.card));
        root.addView(bar, new LinearLayout.LayoutParams(UI.dp(this, 220), UI.dp(this, 6)));

        step = UI.tv(this, "Waking up your assistant…", 14, pal.sub, false);
        step.setGravity(Gravity.CENTER);
        root.addView(step, UI.lp(this, UI.WRAP, UI.WRAP, 0, 14, 0, 0));
        setContentView(root);

        title.animate().alpha(1f).translationY(0).setStartDelay(250).setDuration(700).start();
        welcome.animate().alpha(1f).translationY(0).setStartDelay(750).setDuration(700).start();
        ObjectAnimator p = ObjectAnimator.ofInt(bar, "progress", 0, 1000);
        p.setDuration(3000);
        p.setInterpolator(new AccelerateDecelerateInterpolator());
        p.start();

        SoundFx.play(this, SoundFx.REPLY);
        setStep(900, "Loading your voice…");
        setStep(1800, "Getting things ready…");
        setStep(2500, "Here we go!");
        h.postDelayed(new Runnable() {
            @Override public void run() {
                Intent it = new Intent(SplashActivity.this,
                        Prefs.loggedIn(SplashActivity.this) ? MainActivity.class : LoginActivity.class);
                startActivity(it);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        }, 3200);
    }

    private void setStep(long delay, final String text) {
        h.postDelayed(new Runnable() { @Override public void run() { step.setText(text); } }, delay);
    }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
