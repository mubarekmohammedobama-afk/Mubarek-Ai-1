package com.mubarek.ai;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class SettingsActivity extends AppCompatActivity {
    private Pal pal; private LinearLayout col; private TextView voiceLabel; private TextToSpeech tts; private boolean ttsReady;
    private int dp(float v){return UI.dp(this,v);}
    @Override protected void onCreate(Bundle b){super.onCreate(b);pal=Pal.get(this);UI.window(this,pal);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(pal.bg);root.addView(UI.topBar(this,"OBAMA Settings",pal));ScrollView sv=new ScrollView(this);col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(dp(16),0,dp(16),dp(32));sv.addView(col);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);tts=new TextToSpeech(this,s->ttsReady=s==TextToSpeech.SUCCESS);build();}
    private void header(String s){TextView t=UI.tv(this,s.toUpperCase(),12,pal.accent,true);t.setLetterSpacing(.1f);col.addView(t,UI.lp(this,-2,-2,4,22,0,8));}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setBackground(UI.rect(this,pal.card,18));c.setPadding(dp(16),dp(14),dp(16),dp(14));col.addView(c,new LinearLayout.LayoutParams(-1,-2));return c;}
    private void chips(LinearLayout parent,String[] names,int selected,IntConsumer pick){LinearLayout row=new LinearLayout(this);for(int i=0;i<names.length;i++){final int x=i;TextView t=UI.tv(this,names[i],13,i==selected?0xFFFFFFFF:pal.text,true);t.setGravity(Gravity.CENTER);t.setBackground(UI.rect(this,i==selected?pal.accent:pal.bg,12));t.setPadding(0,dp(10),0,dp(10));t.setOnClickListener(v->pick.accept(x));row.addView(t,UI.lp(this,0,-2,3,0,3,0));((LinearLayout.LayoutParams)t.getLayoutParams()).weight=1;}parent.addView(row);}
    private void slider(LinearLayout p,String label,float cur,Consumer<Float> save){p.addView(UI.tv(this,label,14,pal.sub,false),UI.lp(this,-2,-2,0,12,0,0));SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress(Math.max(0,Math.min(100,Math.round((cur-.5f)*100))));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int y,boolean u){}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){save.accept(.5f+x.getProgress()/100f);}});p.addView(s,new LinearLayout.LayoutParams(-1,-2));}
    private void build(){
        header("Account");LinearLayout a=card();a.addView(UI.tv(this,"Signed in as "+Prefs.displayName(this),16,pal.text,true));TextView logout=UI.button(this,"Log out",pal.bg,pal.text);logout.setOnClickListener(v->{Prefs.logout(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);});a.addView(logout,UI.lp(this,-1,-2,0,12,0,0));
        header("Appearance");chips(card(),Pal.NAMES,Prefs.theme(this),i->{Prefs.setTheme(this,i);recreate();});
        header("Language");chips(card(),new String[]{"English","አማርኛ"},Prefs.amharic(this)?1:0,i->{Prefs.setAmharic(this,i==1);recreate();});
        header("Voice personality");LinearLayout v=card();voiceLabel=UI.tv(this,"",15,pal.text,false);v.addView(voiceLabel);updateVoice();TextView choose=UI.button(this,"Choose assistant voice",pal.accent,0xFFFFFFFF);choose.setOnClickListener(x->chooseProfile());v.addView(choose,UI.lp(this,-1,-2,0,12,0,0));TextView test=UI.button(this,"▶  Preview voice",pal.bg,pal.text);test.setOnClickListener(x->sample());v.addView(test,UI.lp(this,-1,-2,0,8,0,0));SwitchCompat cloud=new SwitchCompat(this);cloud.setText("Use natural AI voice when available");cloud.setTextColor(pal.text);cloud.setTextSize(15);cloud.setChecked(Prefs.cloudVoice(this));cloud.setOnCheckedChangeListener((b,on)->Prefs.setCloudVoice(this,on));v.addView(cloud,UI.lp(this,-1,-2,0,12,0,0));SwitchCompat hands= new SwitchCompat(this);hands.setText("Hands-free voice mode");hands.setTextColor(pal.text);hands.setTextSize(15);hands.setChecked(Prefs.voiceMode(this));hands.setOnCheckedChangeListener((b,on)->Prefs.setVoiceMode(this,on));v.addView(hands,UI.lp(this,-1,-2,0,4,0,0));
        header("Voice tuning");LinearLayout tune=card();slider(tune,"Speech speed",Prefs.rate(this),f->Prefs.setRate(this,f));slider(tune,"Speech pitch",Prefs.pitch(this),f->Prefs.setPitch(this));
        header("Experience");LinearLayout e=card();SwitchCompat sound=new SwitchCompat(this);sound.setText("Sound effects");sound.setTextColor(pal.text);sound.setChecked(Prefs.sound(this));sound.setOnCheckedChangeListener((b,on)->Prefs.setSound(this,on));e.addView(sound);SwitchCompat greet=new SwitchCompat(this);greet.setText("Welcoming voice before listening");greet.setTextColor(pal.text);greet.setChecked(Prefs.greet(this));greet.setOnCheckedChangeListener((b,on)->Prefs.setGreet(this,on));e.addView(greet,UI.lp(this,-1,-2,0,10,0,0));
        header("Data");LinearLayout d=card();TextView clear=UI.button(this,"Clear chat history",0xFFE5484D,0xFFFFFFFF);clear.setOnClickListener(x->new AlertDialog.Builder(this).setMessage("Delete all saved chats?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(q,w)->{ChatStore.clear(this);Toast.makeText(this,"History cleared",Toast.LENGTH_SHORT).show();}).show());d.addView(clear);
        header("About");LinearLayout ab=card();ab.addView(UI.tv(this,"OBAMA 3.0",16,pal.text,true));ab.addView(UI.tv(this,"Mubarek voice assistant • English + አማርኛ • file-aware chat",13,pal.sub,false),UI.lp(this,-1,-2,0,5,0,0));
    }
    private void updateVoice(){VoiceProfile v=VoiceProfile.get(Prefs.voiceProfile(this));voiceLabel.setText("Selected: "+v.name+" — "+v.description+"\nCloud voice: "+v.cloudVoice);}
    private void chooseProfile(){String[] labels=new String[VoiceProfile.ALL.length];int checked=0;for(int i=0;i<labels.length;i++){VoiceProfile v=VoiceProfile.ALL[i];labels[i]=v.name+"  •  "+v.description;if(v.id.equals(Prefs.voiceProfile(this)))checked=i;}new AlertDialog.Builder(this).setTitle("Assistant voice").setSingleChoiceItems(labels,checked,(d,w)->{Prefs.setVoiceProfile(this,VoiceProfile.ALL[w].id);updateVoice();sample();d.dismiss();}).show();}
    private void sample(){VoiceProfile v=VoiceProfile.get(Prefs.voiceProfile(this));String text=Prefs.amharic(this)?"ሰላም፣ እኔ ሙባሬክ ነኝ፣ የOBAMA የድምጽ ረዳት።": "Hello, I'm Mubarek, the voice assistant behind OBAMA. How can I help you today?";if(Prefs.cloudVoice(this)){CloudTts.speak(this,text,BuildConfig.GEMINI_API_KEY,v.cloudVoice,v.style,new CloudTts.Listener(){public void onStart(){}public void onDone(boolean ok,String e){if(!ok)Toast.makeText(SettingsActivity.this,"Voice error: "+e,Toast.LENGTH_LONG).show();}});return;}if(!ttsReady)return;int r=tts.setLanguage(Prefs.amharic(this)?new Locale("am","ET"):Locale.getDefault());if(r<0){Toast.makeText(this,"That language is not installed on this phone.",Toast.LENGTH_LONG).show();return;}tts.setSpeechRate(Prefs.rate(this));tts.setPitch(Prefs.pitch(this));tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"preview");}
    @Override protected void onDestroy(){CloudTts.stop();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
