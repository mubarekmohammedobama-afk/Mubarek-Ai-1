package com.mubarek.ai;

/** Named assistant voices. Cloud profiles use Gemini's supported prebuilt voices. */
final class VoiceProfile {
    final String id, name, description, cloudVoice, style;
    VoiceProfile(String id, String name, String description, String cloudVoice, String style) {
        this.id = id; this.name = name; this.description = description; this.cloudVoice = cloudVoice; this.style = style;
    }
    static final VoiceProfile[] ALL = {
            new VoiceProfile("mubarek", "Mubarek", "Warm, welcoming and natural", "Sulafat", "warm, welcoming and friendly"),
            new VoiceProfile("professional", "Professional", "Clear and informative", "Charon", "professional, clear and confident"),
            new VoiceProfile("friendly", "Friendly", "Casual and approachable", "Achird", "friendly, relaxed and conversational"),
            new VoiceProfile("energetic", "Energetic", "Bright and lively", "Fenrir", "energetic, upbeat and expressive"),
            new VoiceProfile("calm", "Calm", "Soft and reassuring", "Aoede", "calm, gentle and reassuring"),
            new VoiceProfile("deep", "Deep", "Firm and mature", "Orus", "mature, steady and authoritative")
    };
    static VoiceProfile get(String id) {
        for (VoiceProfile v : ALL) if (v.id.equals(id)) return v;
        return ALL[0];
    }
}
