package com.mubarek.ai; // change to your app's package name

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Profile photo in a circle with a glowing, pulsing voice orb around it. */
public class GlowOrbView extends View {
    public enum State { IDLE, LISTENING, SPEAKING }

    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint photo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap bitmap;
    private BitmapShader shader;
    private ValueAnimator animator;
    private float phase = 0f;      // 0..1 looping
    private float level = 0.15f;   // 0..1 voice loudness (smoothed)
    private float targetLevel = 0.15f;
    private State state = State.IDLE;
    private int accent = 0xFF8E7CFF;

    public void setAccent(int a) { accent = a; invalidate(); }

    public GlowOrbView(Context c, AttributeSet a) {
        super(c, a);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(6f);
        ring.setColor(0xFFFFFFFF);
        bitmap = ((BitmapDrawable) c.getResources()
                .getDrawable(R.drawable.ic_obama, null)).getBitmap();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2200);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(v -> {
            phase = (float) v.getAnimatedValue();
            level += (targetLevel - level) * 0.15f;
            invalidate();
        });
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); animator.start(); }
    @Override protected void onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow(); }

    public void setState(State s) {
        state = s;
        targetLevel = (s == State.IDLE) ? 0.15f : 0.5f;
    }

    /** Call with mic RMS (SpeechRecognizer onRmsChanged, about -2..10) for a live reaction. */
    public void setVoiceRms(float rmsDb) {
        float n = Math.max(0f, Math.min(1f, (rmsDb + 2f) / 12f));
        targetLevel = 0.3f + 0.7f * n;
    }

    @Override protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight()) * 0.28f;
        int color = state == State.SPEAKING ? 0xFFFF9F43
                  : state == State.LISTENING ? 0xFF4DA3FF : accent;

        // pulsing glow rings
        for (int i = 0; i < 3; i++) {
            float p = (phase + i / 3f) % 1f;
            float r = base * (1.1f + p * (0.5f + level));
            int alpha = (int) (110 * (1f - p) * (0.4f + level));
            glow.setColor(color);
            glow.setAlpha(Math.max(alpha, 0));
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeWidth(10f + 20f * level);
            glow.setMaskFilter(new BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL));
            canvas.drawCircle(cx, cy, r, glow);
        }
        // soft core glow
        glow.setStyle(Paint.Style.FILL);
        glow.setAlpha(120);
        glow.setMaskFilter(new BlurMaskFilter(60f + 40f * level, BlurMaskFilter.Blur.NORMAL));
        canvas.drawCircle(cx, cy, base * (1.05f + 0.05f * level), glow);
        glow.setMaskFilter(null);

        // circular photo
        if (shader == null) shader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        Matrix m = new Matrix();
        float s = (base * 2f) / bitmap.getWidth();
        m.setScale(s, s);
        m.postTranslate(cx - base, cy - base);
        shader.setLocalMatrix(m);
        photo.setShader(shader);
        canvas.drawCircle(cx, cy, base, photo);
        canvas.drawCircle(cx, cy, base, ring);
    }
}
