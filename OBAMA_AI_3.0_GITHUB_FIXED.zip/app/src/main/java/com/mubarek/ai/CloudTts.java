package com.mubarek.ai;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Gemini TTS using the current generateContent audio endpoint. */
final class CloudTts {
    interface Listener { void onStart(); void onDone(boolean ok, String error); }
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static MediaPlayer player;
    private static int generation;

    static void speak(Context ctx, String text, String apiKey, String voice, String style, Listener listener) {
        final int g = ++generation;
        stop();
        if (apiKey == null || apiKey.trim().isEmpty()) {
            if (listener != null) listener.onDone(false, "Add your Gemini API key in Gradle properties.");
            return;
        }
        IO.execute(() -> {
            try {
                File out = new File(ctx.getCacheDir(), "obama_voice_" + hash(text + voice + style) + ".wav");
                if (!out.exists()) generate(out, text, apiKey, voice, style);
                if (g != generation) return;
                MAIN.post(() -> {
                    try {
                        player = new MediaPlayer();
                        player.setDataSource(out.getAbsolutePath());
                        player.setOnPreparedListener(mp -> {
                            if (listener != null) listener.onStart();
                            mp.start();
                        });
                        player.setOnCompletionListener(mp -> {
                            mp.release(); player = null;
                            if (listener != null) listener.onDone(true, null);
                        });
                        player.setOnErrorListener((mp, what, extra) -> {
                            try { mp.release(); } catch (Exception ignored) {}
                            player = null;
                            if (listener != null) listener.onDone(false, "Audio playback failed.");
                            return true;
                        });
                        player.prepareAsync();
                    } catch (Exception e) {
                        if (listener != null) listener.onDone(false, e.getMessage());
                    }
                });
            } catch (Exception e) {
                if (g == generation) MAIN.post(() -> { if (listener != null) listener.onDone(false, e.getMessage()); });
            }
        });
    }

    private static void generate(File out, String text, String key, String voice, String style) throws Exception {
        JSONObject part = new JSONObject().put("text", text).put("speech_metadata", new JSONObject().put("style", style));
        JSONObject body = new JSONObject()
                .put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(part))))
                .put("generationConfig", new JSONObject()
                        .put("responseModalities", new JSONArray().put("AUDIO"))
                        .put("speechConfig", new JSONObject().put("voiceConfig", new JSONObject().put("prebuiltVoiceConfig", new JSONObject().put("voiceName", voice)))));
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash-tts:generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
        byte[] data = readAll(stream);
        if (code != 200) throw new Exception("TTS error " + code + ": " + new String(data, StandardCharsets.UTF_8));
        JSONObject json = new JSONObject(new String(data, StandardCharsets.UTF_8));
        String b64 = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                .getJSONObject(0).getJSONObject("inlineData").getString("data");
        byte[] audio = Base64.decode(b64, Base64.DEFAULT);
        // Gemini's unary TTS returns a WAV for the current endpoint. If raw PCM is returned,
        // wrap it as 24kHz mono 16-bit WAV so Android MediaPlayer can play it.
        if (audio.length >= 12 && audio[0] == 'R' && audio[1] == 'I' && audio[2] == 'F' && audio[3] == 'F') {
            try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(audio); }
        } else {
            try (FileOutputStream fos = new FileOutputStream(out)) { writeWavHeader(fos, audio.length, 24000, 1, 16); fos.write(audio); }
        }
    }

    private static void writeWavHeader(OutputStream os, int dataLength, int sampleRate, int channels, int bits) throws Exception {
        int byteRate = sampleRate * channels * bits / 8;
        int block = channels * bits / 8;
        os.write(new byte[]{'R','I','F','F'}); le(os, 36 + dataLength, 4); os.write(new byte[]{'W','A','V','E','f','m','t',' '});
        le(os, 16, 4); le(os, 1, 2); le(os, channels, 2); le(os, sampleRate, 4); le(os, byteRate, 4); le(os, block, 2); le(os, bits, 2);
        os.write(new byte[]{'d','a','t','a'}); le(os, dataLength, 4);
    }
    private static void le(OutputStream os, int v, int n) throws Exception { for (int i=0;i<n;i++) os.write((v >> (8*i)) & 255); }
    private static byte[] readAll(InputStream in) throws Exception { java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream(); byte[] x=new byte[8192]; int n; while((n=in.read(x))!=-1)b.write(x,0,n); return b.toByteArray(); }
    private static String hash(String s) { try { byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); for(byte x:d)b.append(String.format("%02x",x)); return b.substring(0,24); } catch(Exception e){return String.valueOf(s.hashCode());} }
    static void stop() { generation++; if (player != null) { try { player.stop(); } catch(Exception ignored){} try { player.release(); } catch(Exception ignored){} player=null; } }
}
