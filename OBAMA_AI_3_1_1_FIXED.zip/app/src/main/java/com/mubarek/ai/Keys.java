package com.mubarek.ai;

import android.content.Context;

/** Finds the Gemini key. Works with both build styles: a Gradle property (BuildConfig) or the strings.xml placeholder. */
final class Keys {
    static String gemini(Context c) {
        String k = BuildConfig.GEMINI_API_KEY;
        if (k != null && !k.trim().isEmpty()) return k.trim();
        try {
            String r = c.getString(R.string.gemini_key);
            if (r != null && !r.contains("PLACEHOLDER") && !r.trim().isEmpty()) return r.trim();
        } catch (Exception ignored) { }
        return "";
    }
}
