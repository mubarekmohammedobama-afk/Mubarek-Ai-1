package com.mubarek.ai;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

public class MainActivity extends AppCompatActivity {
    private Pal pal;
    private int themeAtCreate;
    private GlowOrbView orb;
    private MicButton mic;
    private TextView status, langChip, attachmentChip;
    private EditText input;
    private RecyclerView rv;
    private Adapter adapter;
    private OfflineView offline;

    private final List<Msg> msgs = new ArrayList<>();
    private String convId;

    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady, voiceOk = true, amharic, greeting;

    private Uri pendingUri;
    private String pendingName = "", pendingMime = "";

    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private Boolean lastOnline;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private int generation = 0;
    private boolean gotFirstChunk;

    // speech state: sentences are spoken while the answer is still arriving
    private int speechGen = 0, speechPending = 0, speechSeq = 0;
    private boolean speechCloud, speechDone, listenAfter, replySpeech;
    private final StringBuilder speakBuf = new StringBuilder();

    private int dp(float v) { return UI.dp(this, v); }

    // ------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pal = Pal.get(this);
        themeAtCreate = Prefs.theme(this);
        amharic = Prefs.amharic(this);
        UI.window(this, pal);
        convId = getIntent().getStringExtra("conv");
        if (convId != null) loadConversation(); else convId = String.valueOf(System.currentTimeMillis());
        if (msgs.isEmpty()) addWelcome();
        buildUi();
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { main.post(() -> orb.setState(GlowOrbView.State.SPEAKING)); }
                    @Override public void onDone(String id) { main.post(() -> deviceUtteranceDone(id)); }
                    @Override public void onError(String id) { main.post(() -> deviceUtteranceDone(id)); }
                });
                applyTts();
            }
        });
    }

    @Override protected void onStart() {
        super.onStart();
        updateNet();
        netCb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { main.post(() -> updateNet()); }
            @Override public void onLost(Network n) { main.post(() -> updateNet()); }
            @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities c) { main.post(() -> updateNet()); }
        };
        try { cm.registerDefaultNetworkCallback(netCb); } catch (Exception ignored) { }
    }

    @Override protected void onStop() {
        try { if (netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Prefs.theme(this) != themeAtCreate) { recreate(); return; }
        amharic = Prefs.amharic(this);
        langChip.setText(amharic ? "አማ" : "EN");
        applyTts();
    }

    @Override protected void onDestroy() {
        stopGeneration();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        io.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------ UI
    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(pal.bg);
        root.setFitsSystemWindows(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(4), dp(4), dp(4));
        top.addView(icon(android.R.drawable.ic_menu_sort_by_size, v -> startActivity(new Intent(this, HistoryActivity.class))),
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(6), 0, 0, 0);
        brand.addView(UI.tv(this, "OBAMA", 19, pal.text, true));
        brand.addView(UI.tv(this, "Mubarek voice assistant", 11, pal.sub, false));
        top.addView(brand, new LinearLayout.LayoutParams(0, UI.WRAP, 1));
        langChip = UI.tv(this, amharic ? "አማ" : "EN", 12, pal.text, true);
        langChip.setGravity(Gravity.CENTER);
        langChip.setBackground(UI.rect(this, pal.card, 18));
        langChip.setPadding(dp(12), dp(7), dp(12), dp(7));
        langChip.setOnClickListener(v -> {
            amharic = !amharic;
            Prefs.setAmharic(this, amharic);
            applyTts();
            langChip.setText(amharic ? "አማ" : "EN");
        });
        top.addView(langChip, UI.lp(this, UI.WRAP, UI.WRAP, 0, 0, 4, 0));
        top.addView(icon(android.R.drawable.ic_menu_add, v -> newChat()), new LinearLayout.LayoutParams(dp(42), dp(42)));
        top.addView(icon(android.R.drawable.ic_menu_info_details, v -> startActivity(new Intent(this, AboutActivity.class))),
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        top.addView(icon(android.R.drawable.ic_menu_preferences, v -> startActivity(new Intent(this, SettingsActivity.class))),
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        page.addView(top, new LinearLayout.LayoutParams(-1, dp(60)));

        orb = new GlowOrbView(this, null);
        orb.setAccent(pal.accent);
        page.addView(orb, new LinearLayout.LayoutParams(-1, dp(145)));
        status = UI.tv(this, "Ready when you are", 13, pal.sub, false);
        status.setGravity(Gravity.CENTER);
        page.addView(status, new LinearLayout.LayoutParams(-1, dp(30)));

        rv = new RecyclerView(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setClipToPadding(false);
        rv.setPadding(dp(6), dp(8), dp(6), dp(10));
        adapter = new Adapter();
        rv.setAdapter(adapter);
        page.addView(rv, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composerWrap = new LinearLayout(this);
        composerWrap.setOrientation(LinearLayout.VERTICAL);
        composerWrap.setPadding(dp(10), dp(4), dp(10), dp(10));
        attachmentChip = UI.tv(this, "", 12, pal.sub, false);
        attachmentChip.setVisibility(View.GONE);
        attachmentChip.setGravity(Gravity.CENTER_VERTICAL);
        attachmentChip.setPadding(dp(12), dp(8), dp(12), dp(8));
        attachmentChip.setBackground(UI.rect(this, pal.card, 14));
        attachmentChip.setOnClickListener(v -> clearAttachment());
        composerWrap.addView(attachmentChip, UI.lp(this, -1, dp(34), 0, 0, 0, 6));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.BOTTOM);
        bar.setBackground(UI.rect(this, pal.card, 28));
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));
        bar.setMinimumHeight(dp(58));
        bar.addView(roundIcon(android.R.drawable.ic_menu_add, v -> pickFile()), new LinearLayout.LayoutParams(dp(46), dp(46)));
        input = new EditText(this);
        input.setHint("Message OBAMA");
        input.setHintTextColor(pal.sub);
        input.setTextColor(pal.text);
        input.setTextSize(16);
        input.setMinHeight(dp(46));
        input.setBackground(null);
        input.setPadding(dp(8), dp(8), dp(8), dp(8));
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setOnEditorActionListener((v, a, e) -> {
            if (a == EditorInfo.IME_ACTION_SEND) { sendTyped(); return true; }
            return false;
        });
        bar.addView(input, new LinearLayout.LayoutParams(0, UI.WRAP, 1));
        mic = new MicButton(this);
        mic.setAccent(pal.accent);
        mic.setOnClickListener(v -> micPressed());
        bar.addView(mic, new LinearLayout.LayoutParams(dp(48), dp(48)));
        ImageButton send = roundIcon(android.R.drawable.ic_menu_send, v -> sendTyped());
        send.setContentDescription("Send message");
        bar.addView(send, new LinearLayout.LayoutParams(dp(46), dp(46)));
        composerWrap.addView(bar, new LinearLayout.LayoutParams(-1, UI.WRAP));
        page.addView(composerWrap, new LinearLayout.LayoutParams(-1, UI.WRAP));

        offline = new OfflineView(this);
        offline.setVisibility(View.GONE);
        offline.setClickable(true);
        FrameLayout.LayoutParams ol = new FrameLayout.LayoutParams(-1, -1);
        ol.topMargin = dp(60);
        root.addView(offline, ol);

        setContentView(root);
    }

    private ImageButton icon(int res, View.OnClickListener l) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(res);
        b.setColorFilter(pal.text);
        b.setBackground(null);
        b.setOnClickListener(l);
        b.setContentDescription("OBAMA");
        return b;
    }

    private ImageButton roundIcon(int res, View.OnClickListener l) {
        ImageButton b = icon(res, l);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(pal.accent);
        b.setBackground(g);
        b.setColorFilter(0xFFFFFFFF);
        return b;
    }

    // ------------------------------------------------------------ chat list
    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final TextView bubble, actions;
            VH(LinearLayout box, TextView t, TextView a) { super(box); bubble = t; actions = a; }
        }

        @Override public VH onCreateViewHolder(ViewGroup p, int type) {
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(8), dp(5), dp(8), dp(5));
            TextView t = UI.tv(MainActivity.this, "", 16, pal.text, false);
            t.setPadding(dp(15), dp(12), dp(15), dp(12));
            t.setLineSpacing(0, 1.08f);
            t.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.82f));
            TextView a = UI.tv(MainActivity.this, "Copy   •   Speak   •   Regenerate", 11, pal.sub, false);
            a.setPadding(dp(8), dp(4), dp(8), dp(2));
            box.addView(t, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
            box.addView(a, new LinearLayout.LayoutParams(UI.WRAP, UI.WRAP));
            return new VH(box, t, a);
        }

        @Override public void onBindViewHolder(VH h, int pos) {
            Msg m = msgs.get(pos);
            h.bubble.setText(m.text);
            h.bubble.setBackground(UI.rect(MainActivity.this, m.user ? pal.accent : pal.card, 20));
            h.bubble.setTextColor(m.user ? 0xFFFFFFFF : pal.text);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) h.bubble.getLayoutParams();
            lp.gravity = m.user ? Gravity.END : Gravity.START;
            h.bubble.setLayoutParams(lp);
            boolean showActions = !m.user && !m.skip;
            h.actions.setVisibility(showActions ? View.VISIBLE : View.GONE);
            h.actions.setOnClickListener(v -> showActions(h.getBindingAdapterPosition()));
        }

        @Override public int getItemCount() { return msgs.size(); }
    }

    private void showActions(int pos) {
        if (pos < 0 || pos >= msgs.size()) return;
        final Msg m = msgs.get(pos);
        new AlertDialog.Builder(this).setItems(new String[]{"Copy response", "Speak response", "Regenerate"}, (d, w) -> {
            if (w == 0) {
                ClipboardManager c = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (c != null) c.setPrimaryClip(ClipData.newPlainText("OBAMA", m.text));
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            } else if (w == 1) {
                speakWhole(m.text, false, false);
            } else {
                regenerate();
            }
        }).show();
    }

    private void scrollEnd() { if (!msgs.isEmpty()) rv.scrollToPosition(msgs.size() - 1); }

    private void loadConversation() {
        JSONObject c = ChatStore.get(this, convId);
        if (c == null) return;
        try {
            JSONArray a = c.getJSONArray("msgs");
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                msgs.add(new Msg(o.getBoolean("u"), o.getString("t")));
            }
        } catch (Exception ignored) { }
    }

    private void newChat() {
        stopGeneration();
        msgs.clear();
        convId = String.valueOf(System.currentTimeMillis());
        addWelcome();
        adapter.notifyDataSetChanged();
        status.setText("New conversation");
        scrollEnd();
    }

    private void addWelcome() {
        String n = Prefs.displayName(this);
        boolean named = !n.equals("Guest") && !n.isEmpty();
        String t = amharic
                ? "ሰላም" + (named ? " " + n : "") + "! እኔ ሙባሬክ ነኝ፣ የOBAMA የድምጽ ረዳት። ጥያቄ ይጠይቁኝ፣ ፋይል ያያይዙ ወይም ማይኩን ተጭነው ይናገሩ።"
                : "Hi" + (named ? " " + n : "") + "! I'm Mubarek, the voice assistant behind OBAMA. Ask me anything, attach a file, or tap the microphone and talk.";
        Msg w = new Msg(false, t);
        w.skip = true; // shown on screen only, never sent to the AI or saved
        msgs.add(w);
    }

    private String firstUserText() {
        for (Msg m : msgs) if (m.user && !m.skip) return m.text;
        return "Chat";
    }

    // ------------------------------------------------------------ speech output
    private void applyTts() {
        if (!ttsReady) return;
        tts.setSpeechRate(Prefs.rate(this));
        tts.setPitch(Prefs.pitch(this));
        voiceOk = true;
        Locale loc = amharic ? new Locale("am", "ET") : Locale.getDefault();
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { voiceOk = false; return; }
        String vn = Prefs.voice(this);
        if (!vn.isEmpty()) {
            try {
                for (Voice v : tts.getVoices()) {
                    if (v.getName().equals(vn) && v.getLocale().getLanguage().equals(loc.getLanguage())) { tts.setVoice(v); break; }
                }
            } catch (Exception ignored) { }
        }
    }

    private boolean haveKey() {
        return !Keys.gemini(this).isEmpty();
    }

    /** Natural online voice when chosen (or when the phone has no voice for the language). */
    private boolean useCloudVoice() {
        boolean deviceOk = ttsReady && voiceOk;
        if (!deviceOk) return haveKey() || !ttsReady;
        return Prefs.cloudVoice(this) && haveKey();
    }

    private void stopSpeech() {
        speechGen++;
        if (tts != null) tts.stop();
        CloudTts.stop();
    }

    private void beginSpeech(boolean forReply, boolean thenListen) {
        stopSpeech();
        speechCloud = useCloudVoice();
        speechPending = 0; speechSeq = 0; speechDone = false;
        speakBuf.setLength(0);
        replySpeech = forReply;
        listenAfter = thenListen;
        if (speechCloud) {
            final int g = speechGen;
            VoiceProfile v = VoiceProfile.get(Prefs.voiceProfile(this));
            CloudTts.begin(this, Keys.gemini(this), v.cloudVoice, v.style, new CloudTts.Listener() {
                @Override public void onStart() { if (g == speechGen) orb.setState(GlowOrbView.State.SPEAKING); }
                @Override public void onDone(boolean ok, String err) { if (g == speechGen) speechFinished(ok, err); }
            });
        }
    }

    private void feedSpeech(String delta) {
        speakBuf.append(delta);
        flushSentences(false);
    }

    private void endSpeech() {
        flushSentences(true);
        speechDone = true;
        if (speechCloud) CloudTts.end();
        else if (speechPending <= 0) speechFinished(true, null);
    }

    private void flushSentences(boolean end) {
        String s = speakBuf.toString();
        int cut = -1;
        for (int i = s.length() - 1; i >= 0; i--) {
            char ch = s.charAt(i);
            if (ch == '.' || ch == '!' || ch == '?' || ch == '።' || ch == '\n') { cut = i; break; }
        }
        String part;
        if (end) { part = s; speakBuf.setLength(0); }
        else if (cut >= 20) { part = s.substring(0, cut + 1); speakBuf.delete(0, cut + 1); }
        else return;
        part = clean(part);
        if (part.isEmpty()) return;
        if (speechCloud) {
            CloudTts.enqueue(part);
        } else {
            speechPending++;
            tts.speak(part, TextToSpeech.QUEUE_ADD, null, "s" + speechGen + "_" + (speechSeq++));
        }
    }

    private void deviceUtteranceDone(String id) {
        if (id == null || !id.startsWith("s" + speechGen + "_")) return;
        speechPending--;
        if (speechPending <= 0 && speechDone) speechFinished(true, null);
    }

    private void speechFinished(boolean ok, String err) {
        orb.setState(GlowOrbView.State.IDLE);
        status.setText(ok ? "Ready when you are" : "Voice unavailable: " + err);
        boolean again = ok && replySpeech && Prefs.voiceMode(this);
        replySpeech = false;
        if (listenAfter) {
            listenAfter = false;
            greeting = false;
            startListening();
        } else if (again) {
            startListening();
        }
    }

    private void speakWhole(String text, boolean forReply, boolean thenListen) {
        beginSpeech(forReply, thenListen);
        feedSpeech(text);
        endSpeech();
    }

    private String clean(String s) { return s.replace("*", "").replace("#", "").trim(); }

    // ------------------------------------------------------------ mic
    private void micPressed() {
        if (greeting) { // tapped again: skip the greeting
            greeting = false;
            listenAfter = false;
            stopSpeech();
            startListening();
            return;
        }
        if (!Prefs.greet(this) || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startListening();
            return;
        }
        String[] g = amharic
                ? new String[]{"ሰላም! ሙባሬክ እያዳመጠ ነው። እንጀምር።", "እንኳን ደህና መጡ። ምን ልርዳዎት?"}
                : new String[]{"Hi, I'm Mubarek. I'm listening.", "Welcome to OBAMA. Go ahead, I'm listening.", "Hello! Mubarek here. What can I help you with?"};
        String text = g[(int) (Math.random() * g.length)];
        greeting = true;
        status.setText(text);
        speakWhole(text, false, true);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech recognition is not available on this phone");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        stopSpeech();
        SoundFx.play(this, SoundFx.START);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, amharic ? "am-ET" : Locale.getDefault().toLanguageTag());
        recognizer.startListening(i);
        mic.setActive(true);
        orb.setState(GlowOrbView.State.LISTENING);
        status.setText("Listening…");
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == 7 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else status.setText("Microphone permission is needed");
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle b) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rms) { orb.setVoiceRms(rms); }
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() { mic.setActive(false); status.setText("Thinking…"); }
        @Override public void onError(int e) {
            mic.setActive(false);
            orb.setState(GlowOrbView.State.IDLE);
            status.setText("I didn't catch that. Try again.");
        }
        @Override public void onResults(Bundle r) {
            mic.setActive(false);
            ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (a != null && !a.isEmpty()) submit(a.get(0), true);
            else orb.setState(GlowOrbView.State.IDLE);
        }
        @Override public void onPartialResults(Bundle b) {}
        @Override public void onEvent(int t, Bundle b) {}
    };

    // ------------------------------------------------------------ attachments
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        startActivityForResult(i, 44);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r != 44 || c != RESULT_OK || d == null) return;
        Uri u = d.getData();
        if (u == null && d.getClipData() != null) u = d.getClipData().getItemAt(0).getUri();
        if (u == null) return;
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
        pendingUri = u;
        pendingName = queryName(u);
        pendingMime = getContentResolver().getType(u);
        if (pendingMime == null) pendingMime = "application/octet-stream";
        attachmentChip.setText("📎  " + pendingName + "   •   tap to remove");
        attachmentChip.setVisibility(View.VISIBLE);
    }

    private String queryName(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return "Attached file";
    }

    private void clearAttachment() {
        pendingUri = null; pendingName = ""; pendingMime = "";
        attachmentChip.setVisibility(View.GONE);
    }

    private static class Attachment { String mime, name, error; byte[] data; }

    private Attachment readPendingAttachment() {
        Attachment a = new Attachment();
        if (pendingUri == null) return a;
        a.mime = pendingMime;
        a.name = pendingName;
        final int max = 7 * 1024 * 1024;
        try {
            long len = -1;
            try (Cursor c = getContentResolver().query(pendingUri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) len = c.getLong(0);
            }
            if (len > max) { a.error = "That file is larger than 7 MB. Please choose a smaller file."; return a; }
            try (InputStream in = getContentResolver().openInputStream(pendingUri)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > max) { a.error = "That file is larger than 7 MB."; return a; }
                }
                a.data = out.toByteArray();
            }
        } catch (Exception e) {
            a.error = "Couldn't read the attachment: " + e.getMessage();
        }
        return a;
    }

    // ------------------------------------------------------------ sending
    private void sendTyped() {
        String t = input.getText().toString().trim();
        if (t.isEmpty() && pendingUri == null) return;
        input.setText("");
        submit(t.isEmpty() ? "Please analyze the attached file." : t, true);
    }

    private void regenerate() {
        String last = null;
        for (int i = msgs.size() - 1; i >= 0; i--) {
            if (msgs.get(i).user && !msgs.get(i).skip) { last = msgs.get(i).text; break; }
        }
        if (last == null) return;
        // drop the old answer so the AI doesn't see it again
        while (!msgs.isEmpty() && !msgs.get(msgs.size() - 1).user) msgs.remove(msgs.size() - 1);
        submit(last, false);
    }

    private void submit(String text, boolean addUser) {
        if (!isOnline()) {
            SoundFx.play(this, SoundFx.ERROR);
            status.setText("No internet connection");
            orb.setState(GlowOrbView.State.IDLE);
            return;
        }
        final Attachment att = readPendingAttachment();
        if (att.error != null) { Toast.makeText(this, att.error, Toast.LENGTH_LONG).show(); return; }
        clearAttachment();
        SoundFx.play(this, SoundFx.SEND);
        if (addUser) msgs.add(new Msg(true, att.data != null ? "📎 " + att.name + "\n" + text : text));
        stopGeneration();
        final String body;
        try { body = buildBody(att); }
        catch (Exception e) { Toast.makeText(this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show(); return; }

        final Msg answer = new Msg(false, "Thinking…");
        msgs.add(answer);
        adapter.notifyDataSetChanged();
        scrollEnd();
        status.setText("Thinking…");
        orb.setState(GlowOrbView.State.THINKING);
        gotFirstChunk = false;
        final int my = ++generation;
        beginSpeech(true, false);

        io.execute(() -> {
            final boolean[] got = {false};
            try {
                streamGemini(body, chunk -> {
                    got[0] = true;
                    main.post(() -> onChunk(answer, chunk, my));
                });
                main.post(() -> finish(answer, true, null, my));
            } catch (Exception e) {
                final String err = e.getMessage();
                main.post(() -> finish(answer, got[0], err, my));
            }
        });
    }

    private void onChunk(Msg answer, String d, int my) {
        if (my != generation) return;
        if (!gotFirstChunk) {
            gotFirstChunk = true;
            answer.text = "";
            status.setText("Mubarek is replying…");
            SoundFx.play(this, SoundFx.REPLY);
        }
        answer.text += d;
        int i = msgs.indexOf(answer);
        if (i >= 0) adapter.notifyItemChanged(i);
        scrollEnd();
        feedSpeech(d);
    }

    private void finish(Msg answer, boolean ok, String err, int my) {
        if (my != generation) return;
        if (!ok) {
            answer.text = err == null ? "Something went wrong." : err;
            answer.skip = true; // failed turns are shown but never sent back to the AI
            for (int i = msgs.size() - 1; i >= 0; i--) {
                if (msgs.get(i).user) { msgs.get(i).skip = true; break; }
            }
            SoundFx.play(this, SoundFx.ERROR);
            stopSpeech();
            adapter.notifyDataSetChanged();
            scrollEnd();
            status.setText("Ready when you are");
            orb.setState(GlowOrbView.State.IDLE);
            return;
        }
        String title = firstUserText();
        ChatStore.save(this, convId, title.length() > 40 ? title.substring(0, 40) + "…" : title, msgs);
        adapter.notifyDataSetChanged();
        scrollEnd();
        endSpeech();
    }

    private void stopGeneration() {
        generation++;
        stopSpeech();
        greeting = false;
        listenAfter = false;
        if (mic != null) mic.setActive(false);
        if (orb != null) orb.setState(GlowOrbView.State.IDLE);
    }

    private String buildBody(Attachment att) throws Exception {
        JSONArray contents = new JSONArray();
        int lastUser = -1;
        for (int i = msgs.size() - 1; i >= 0; i--) {
            if (msgs.get(i).user && !msgs.get(i).skip) { lastUser = i; break; }
        }
        for (int i = Math.max(0, msgs.size() - 20); i < msgs.size(); i++) {
            Msg m = msgs.get(i);
            if (m.skip) continue;
            if (contents.length() == 0 && !m.user) continue;
            JSONArray parts = new JSONArray().put(new JSONObject().put("text", m.text));
            if (att.data != null && i == lastUser) {
                parts.put(new JSONObject().put("inline_data", new JSONObject()
                        .put("mime_type", att.mime)
                        .put("data", Base64.encodeToString(att.data, Base64.NO_WRAP))));
            }
            contents.put(new JSONObject().put("role", m.user ? "user" : "model").put("parts", parts));
        }
        JSONObject sys = new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text",
                "You are Mubarek, the friendly voice assistant inside an app named OBAMA. Be helpful, accurate and natural. "
                        + "Reply in the user's language. If they use Amharic, answer in Amharic. "
                        + "When speaking aloud, avoid excessive markdown. You can analyze attached files when supplied. "
                        + "Keep conversational answers concise unless the user asks for detail.")));
        return new JSONObject().put("system_instruction", sys).put("contents", contents).toString();
    }

    // ------------------------------------------------------------ AI (streamed)
    private static final String[] MODELS = {"gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-3-flash-preview"};
    private static int goodModel = 0;

    private static class RetryableException extends Exception {
        RetryableException(String m) { super(m); }
    }

    /** Fastest model first; remembers whichever one worked last. Falls back if one is busy or unavailable. */
    private void streamGemini(String body, Consumer<String> cb) throws Exception {
        Exception last = null;
        for (int round = 0; round < 2; round++) {
            for (int k = 0; k < MODELS.length; k++) {
                int idx = (goodModel + k) % MODELS.length;
                try { streamModel(MODELS[idx], body, cb); goodModel = idx; return; }
                catch (RetryableException e) { last = e; }
            }
            try { Thread.sleep(1000); } catch (InterruptedException ignored) { }
        }
        throw new Exception(last == null ? "AI is busy. Try again in a moment." : last.getMessage());
    }

    private void streamModel(String model, String body, Consumer<String> cb) throws Exception {
        if (!haveKey()) throw new Exception("This build has no AI key. On GitHub, save your key as a repository secret named GEMINI_KEY (or GEMINI_API_KEY), then re-run the build.");
        URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":streamGenerateContent?alt=sse");
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", Keys.gemini(this));
        try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        if (code != 200) {
            InputStream es = c.getErrorStream();
            StringBuilder e = new StringBuilder();
            if (es != null) {
                BufferedReader eb = new BufferedReader(new InputStreamReader(es, StandardCharsets.UTF_8));
                String l;
                while ((l = eb.readLine()) != null) e.append(l);
            }
            String msg = "Error " + code + ": " + parseError(e.toString());
            if (code == 503 || code == 429 || code == 404 || code == 500) throw new RetryableException(msg);
            throw new Exception(msg);
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        String line;
        boolean any = false;
        while ((line = br.readLine()) != null) {
            if (!line.startsWith("data:")) continue;
            String json = line.substring(5).trim();
            if (json.isEmpty()) continue;
            try {
                JSONArray cand = new JSONObject(json).optJSONArray("candidates");
                if (cand == null || cand.length() == 0) continue;
                JSONObject content = cand.getJSONObject(0).optJSONObject("content");
                if (content == null) continue;
                JSONArray parts = content.optJSONArray("parts");
                if (parts == null) continue;
                for (int i = 0; i < parts.length(); i++) {
                    String t = parts.getJSONObject(i).optString("text", "");
                    if (!t.isEmpty()) { any = true; cb.accept(t); }
                }
            } catch (Exception ignored) { }
        }
        if (!any) throw new Exception("The AI gave no answer. Try asking again.");
    }

    private String parseError(String s) {
        try { return new JSONObject(s).getJSONObject("error").optString("message", s); }
        catch (Exception e) { return s; }
    }

    // ------------------------------------------------------------ network
    private boolean isOnline() {
        try {
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            return nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Exception e) { return true; }
    }

    private void updateNet() {
        if (offline == null) return;
        boolean now = isOnline();
        if (lastOnline != null && lastOnline == now) return;
        boolean first = lastOnline == null;
        lastOnline = now;
        if (!now) {
            offline.setVisibility(View.VISIBLE);
            offline.setAlpha(0f);
            offline.animate().alpha(1f).setDuration(350).start();
            if (!first) SoundFx.play(this, SoundFx.ERROR);
        } else {
            offline.animate().alpha(0f).setDuration(350).withEndAction(() -> offline.setVisibility(View.GONE)).start();
            if (!first) SoundFx.play(this, SoundFx.ONLINE);
        }
    }
}
